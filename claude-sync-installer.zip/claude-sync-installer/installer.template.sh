#!/usr/bin/env bash
# =====================================================================================================================
# Claude Enterprise -> Wazuh sync: one-shot installer (everything up to the indexer; the dashboard is NOT included)
#
# What it sets up on a host that runs the Wazuh manager:
#   1. /opt/claude/claude_sync.py          the sync service (activities, token usage + spend, content scan)
#   2. claude-sync.service                 systemd unit. The Compliance key is stored ONCE, as Environment= of the
#                                          wazuh-dashboard unit (the equivalent of `systemctl edit wazuh-dashboard`,
#                                          file .../wazuh-dashboard.service.d/override.conf, mode 0600); the sync reads
#                                          it from there. Hosts without that unit get a claude-sync drop-in instead.
#   3. /var/ossec/etc/rules/claude_*.xml   Wazuh rules 101700-101836
#   4. three <localfile> blocks in /var/ossec/etc/ossec.conf (json files written by the sync)
#   5. a logrotate policy for the JSONL buffers
#   6. the claude-alert-state index in the indexer (alert acknowledge / close state, used by the dashboard later)
#   7. an end-to-end check: waits until the events show up in wazuh-alerts-*
#
# It asks for the Compliance API key and the indexer password (typed hidden). The key is written only to the systemd
# drop-in described above; the indexer password is never stored (used to verify the pipeline and create the state index).
#
# Usage:   sudo bash install-claude-sync.sh [--yes] [--uninstall] [--purge]
#   --yes        do not ask before restarting wazuh-manager
#   --uninstall  stop and remove the service, rules, localfile blocks and logrotate policy (keeps data)
#   --purge      with --uninstall: also delete /opt/claude and /etc/claude-sync
# Non-interactive: export CLAUDE_COMPLIANCE_KEY, INDEXER_PASSWORD (and optionally INDEXER_URL, INDEXER_USER, INDEXER_CA).
# =====================================================================================================================
set -euo pipefail

YES=0; UNINSTALL=0; PURGE=0
for a in "$@"; do
  case "$a" in
    --yes|-y) YES=1 ;; --uninstall) UNINSTALL=1 ;; --purge) PURGE=1 ;;
    -h|--help) sed -n 2,26p "$0"; exit 0 ;;
    *) echo "unknown option: $a" >&2; exit 2 ;;
  esac
done

SYNC_DIR=/opt/claude
ENV_DIR=/etc/claude-sync
UNIT=/etc/systemd/system/claude-sync.service
DROPIN_DIR=/etc/systemd/system/claude-sync.service.d
WD_OVERRIDE=/etc/systemd/system/wazuh-dashboard.service.d/override.conf
RULES_DIR=/var/ossec/etc/rules
OSSEC_CONF=/var/ossec/etc/ossec.conf
STATE_INDEX=claude-alert-state
API_CHECK_URL="https://api.anthropic.com/v1/compliance/activities?limit=1"
RULE_FILES="claude_rules.xml claude_security_rules.xml claude_usage_rules.xml claude_dlp_rules.xml"
LOCALFILES="claude_activities.jsonl claude_usage.jsonl claude_content.jsonl"
STAMP=$(date +%Y%m%d-%H%M%S)

if [ -t 1 ]; then B=$'\e[1m'; G=$'\e[32m'; Y=$'\e[33m'; R=$'\e[31m'; N=$'\e[0m'; else B=; G=; Y=; R=; N=; fi
step() { echo; echo "${B}==> $*${N}"; }
ok()   { echo "  ${G}ok${N}  $*"; }
warn() { echo "  ${Y}warn${N} $*"; }
die()  { echo "  ${R}error${N} $*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "run as root (sudo bash $0)"
command -v systemctl >/dev/null || die "systemd is required"
command -v curl >/dev/null || die "curl is required"
command -v python3 >/dev/null || die "python3 is required"
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' || die "python3 >= 3.8 is required"
[ -x /var/ossec/bin/wazuh-control ] || die "Wazuh manager not found in /var/ossec (run this on the Wazuh manager host)"

# ------------------------------------------------------------------------------------------------ uninstall
if [ "$UNINSTALL" -eq 1 ]; then
  step "Uninstalling the Claude sync"
  systemctl disable --now claude-sync 2>/dev/null || true
  rm -f "$UNIT"; rm -rf "$DROPIN_DIR"
  if [ -f "$WD_OVERRIDE" ]; then python3 - "$WD_OVERRIDE" <<'PY'
import re, sys
p = sys.argv[1]; L = open(p).read().splitlines(True)
n = [l for l in L if not re.match(r'\s*Environment=\s*"?ANTHROPIC_COMPLIANCE_KEY=', l)]
if len(n) != len(L): open(p, "w").writelines(n)
PY
  fi
  systemctl daemon-reload
  for f in $RULE_FILES; do rm -f "$RULES_DIR/$f"; done
  rm -f /etc/logrotate.d/claude-sync
  python3 - "$OSSEC_CONF" "$STAMP" <<'PY'
import re, shutil, sys
p, stamp = sys.argv[1], sys.argv[2]
s = open(p).read()
n = re.sub(r"\n[ \t]*<localfile>\s*<log_format>json</log_format>\s*<location>/opt/claude/claude_(?:activities|usage|content)\.jsonl</location>\s*</localfile>[ \t]*", "", s)
if n != s:
    shutil.copy(p, p + ".bak-claude-" + stamp); open(p, "w").write(n)
PY
  if [ "$PURGE" -eq 1 ]; then rm -rf "$SYNC_DIR" "$ENV_DIR"; ok "removed $SYNC_DIR and $ENV_DIR"; else warn "kept $SYNC_DIR and $ENV_DIR (use --purge to delete)"; fi
  ok "removed. Restart wazuh-manager to unload the rules: systemctl restart wazuh-manager"
  exit 0
fi

# ------------------------------------------------------------------------------------------------ network (first check)
step "Checking that this server can reach the Anthropic API (api.anthropic.com:443)"
ANTHROPIC_HOST=api.anthropic.com
if [ -z "${HTTPS_PROXY:-}${https_proxy:-}" ] && command -v getent >/dev/null && ! getent hosts "$ANTHROPIC_HOST" >/dev/null 2>&1; then
  die "DNS: $ANTHROPIC_HOST does not resolve from this server. Check the VPC DNS settings (enableDnsSupport), the resolver in /etc/resolv.conf, or a private DNS zone."
fi
# Any HTTP answer (even 401/404 without a key) proves DNS, the TCP connection, TLS and the egress path all work.
net_code=$(curl -sS -o /dev/null -w '%{http_code}' --connect-timeout 10 -m 25 "https://$ANTHROPIC_HOST/v1/compliance/organizations" 2>/tmp/claude-net-check.err) && net_rc=0 || net_rc=$?
if [ "$net_rc" -ne 0 ]; then
  case "$net_rc" in
    6)  why="DNS: the name does not resolve." ;;
    7)  why="the connection was refused or reset on port 443." ;;
    28) why="the connection timed out. This is the typical sign of a firewall dropping outbound traffic: check the instance's Security Group (outbound rule for TCP 443), the subnet's Network ACL (outbound 443 and the inbound ephemeral ports 1024-65535), the route table (internet gateway or NAT gateway) and any proxy/egress filter." ;;
    35|51|58|60|77) why="TLS: the handshake or certificate check failed. A TLS-inspecting proxy or firewall is probably re-signing the traffic; install its CA certificate on this server." ;;
    5|56) why="the proxy refused or dropped the connection (check HTTPS_PROXY / NO_PROXY)." ;;
    *)  why="curl exit code $net_rc." ;;
  esac
  cat /tmp/claude-net-check.err >&2 2>/dev/null || true
  die "cannot reach https://$ANTHROPIC_HOST from this server: $why
        The sync only talks to this one host (HTTPS, port 443). Ask the network/AWS admin to allow outbound access, then run this script again.
        Quick test:  curl -v https://$ANTHROPIC_HOST/v1/compliance/organizations   (a 401 or 404 answer means the path is open)"
fi
ok "reached $ANTHROPIC_HOST (HTTP $net_code): DNS, port 443 and TLS work from this server"

# ------------------------------------------------------------------------------------------------ prompts
step "Settings"
if [ -t 0 ]; then TTY=/dev/stdin; elif { : </dev/tty; } 2>/dev/null; then TTY=/dev/tty; else TTY=""; fi
ask_secret() {  # ask_secret VAR "prompt"
  local var=$1 prompt=$2 v=""
  if [ -n "${!var:-}" ]; then return; fi
  [ -n "$TTY" ] || die "$var is not set and there is no terminal to ask on (export $var=... and run again)"
  while [ -z "$v" ]; do read -rsp "$prompt: " v < "$TTY"; echo >&2; done
  printf -v "$var" '%s' "$v"
}
ask() {  # ask VAR "prompt" default
  local var=$1 prompt=$2 def=$3 v=""
  if [ -n "${!var:-}" ]; then return; fi
  if [ -n "$TTY" ]; then read -rp "$prompt [$def]: " v < "$TTY"; fi
  printf -v "$var" '%s' "${v:-$def}"
}
CLAUDE_COMPLIANCE_KEY=${CLAUDE_COMPLIANCE_KEY:-}; INDEXER_PASSWORD=${INDEXER_PASSWORD:-}
INDEXER_URL=${INDEXER_URL:-}; INDEXER_USER=${INDEXER_USER:-}
ask_secret CLAUDE_COMPLIANCE_KEY "Anthropic Compliance API key"
ask INDEXER_URL "Wazuh indexer URL" "https://127.0.0.1:9200"
ask INDEXER_USER "Wazuh indexer user" "admin"
ask_secret INDEXER_PASSWORD "Wazuh indexer password for '$INDEXER_USER'"
INDEXER_URL=${INDEXER_URL%/}
INDEXER_CA=${INDEXER_CA:-/etc/wazuh-indexer/certs/root-ca.pem}
if [ -r "$INDEXER_CA" ]; then CA_OPT=(--cacert "$INDEXER_CA"); else CA_OPT=(-k); fi

# curl with the password kept off the command line (it would show in ps)
cfg_escape() { local s=$1; s=${s//\\/\\\\}; s=${s//\"/\\\"}; printf '%s' "$s"; }
ix() { curl -sS "${CA_OPT[@]}" -K <(printf 'user = "%s"\n' "$(cfg_escape "$INDEXER_USER:$INDEXER_PASSWORD")") "$@"; }

# ------------------------------------------------------------------------------------------------ checks
step "Checking the Compliance API key"
code=$(curl -sS -o /dev/null -w '%{http_code}' -m 30 -K <(printf 'header = "x-api-key: %s"\n' "$(cfg_escape "$CLAUDE_COMPLIANCE_KEY")") \
       -H "anthropic-version: 2023-06-01" "$API_CHECK_URL" || echo 000)
case "$code" in
  200) ok "the Compliance API accepted the key" ;;
  401|403|404) die "the Compliance API rejected the key (HTTP $code; Anthropic answers 404 for an unknown key). Check the key and that it has the read:compliance_activities scope" ;;
  000) warn "could not reach api.anthropic.com (network or proxy?)"; [ "$YES" -eq 1 ] || { [ -n "$TTY" ] || exit 1; read -rp "  continue anyway? [y/N] " a < "$TTY"; [ "${a,,}" = y ] || exit 1; } ;;
  *) warn "unexpected HTTP $code from the Compliance API"; [ "$YES" -eq 1 ] || { [ -n "$TTY" ] || exit 1; read -rp "  continue anyway? [y/N] " a < "$TTY"; [ "${a,,}" = y ] || exit 1; } ;;
esac

step "Checking the Wazuh indexer"
code=$(ix -o /dev/null -w '%{http_code}' -m 20 "$INDEXER_URL/" || echo 000)
case "$code" in
  200) ok "indexer reachable, credentials accepted" ;;
  401) die "the indexer rejected the user/password" ;;
  *) die "the indexer at $INDEXER_URL did not answer (HTTP $code)" ;;
esac
ix -m 20 "$INDEXER_URL/_cat/indices/wazuh-alerts-*?h=index" | head -1 | grep -q wazuh-alerts && ok "wazuh-alerts-* indices exist" \
  || warn "no wazuh-alerts-* index yet (it is created when the first alert arrives)"

if ! command -v pdftotext >/dev/null; then
  warn "pdftotext not found: PDFs will not be content-scanned. Install poppler-utils (apt) or poppler-utils (dnf/yum) to enable it."
fi

# ------------------------------------------------------------------------------------------------ files
step "Installing the sync service"
GRP=root; getent group wazuh >/dev/null && GRP=wazuh
install -d -m 2750 -o root -g "$GRP" "$SYNC_DIR"
install -d -m 0750 -o root -g root "$ENV_DIR"
write_file() {  # write_file path mode owner:group  (content on stdin)
  local path=$1 mode=$2 own=$3 tmp; tmp=$(mktemp)
  cat > "$tmp"
  if [ -e "$path" ] && ! cmp -s "$tmp" "$path"; then cp -p "$path" "$path.bak-$STAMP"; fi
  install -m "$mode" -o "${own%%:*}" -g "${own##*:}" "$tmp" "$path"; rm -f "$tmp"
}
write_file "$SYNC_DIR/claude_sync.py" 0750 root:$GRP <<'__EOF_claude_sync_py__'
@@FILE:src/claude_sync.py@@
__EOF_claude_sync_py__
ok "$SYNC_DIR/claude_sync.py"

if [ -e "$ENV_DIR/env" ]; then ok "kept your existing $ENV_DIR/env"; else
write_file "$ENV_DIR/env" 0600 root:root <<'__EOF_env__'
@@FILE:src/env.defaults@@
__EOF_env__
ok "$ENV_DIR/env (tunables, no secrets)"; fi

write_file "$UNIT" 0644 root:root <<'__EOF_unit__'
@@FILE:src/claude-sync.service@@
__EOF_unit__
SETKEY=$(mktemp)
cat > "$SETKEY" <<'__EOF_set_key__'
@@FILE:src/set_key.py@@
__EOF_set_key__
if systemctl cat wazuh-dashboard >/dev/null 2>&1; then
  KEY_TARGET="$WD_OVERRIDE"; KEY_UNIT=wazuh-dashboard
  install -d -m 0755 -o root -g root "$(dirname "$WD_OVERRIDE")"
else
  KEY_TARGET="$DROPIN_DIR/10-credentials.conf"; KEY_UNIT=claude-sync
  install -d -m 0750 -o root -g root "$DROPIN_DIR"
  warn "no wazuh-dashboard unit on this host: storing the key in the claude-sync drop-in instead"
fi
NEW_KEY="$CLAUDE_COMPLIANCE_KEY" python3 "$SETKEY" "$KEY_TARGET"; rm -f "$SETKEY"
chmod 0600 "$KEY_TARGET"
# an older install kept the key in the env file: remove it so there is exactly one copy
if [ -f "$ENV_DIR/env" ] && grep -q '^ANTHROPIC_COMPLIANCE_KEY=' "$ENV_DIR/env"; then sed -i '/^ANTHROPIC_COMPLIANCE_KEY=/d' "$ENV_DIR/env"; ok "removed the old key line from $ENV_DIR/env"; fi
if [ "$KEY_UNIT" = wazuh-dashboard ]; then rm -rf "$DROPIN_DIR"; fi
systemctl daemon-reload
if systemctl show "$KEY_UNIT" --property=Environment --value | grep -q 'ANTHROPIC_COMPLIANCE_KEY='; then
  ok "Compliance key stored in $KEY_TARGET (mode 0600; change it with: systemctl edit $KEY_UNIT)"
else die "the key was not picked up by systemd from $KEY_TARGET"; fi
if [ "$KEY_UNIT" = wazuh-dashboard ]; then ok "no restart of wazuh-dashboard is needed: the sync reads the key from the unit's configuration"; fi

write_file /etc/logrotate.d/claude-sync 0644 root:root <<'__EOF_logrotate__'
@@FILE:src/claude-sync.logrotate@@
__EOF_logrotate__
ok "/etc/logrotate.d/claude-sync"

# ------------------------------------------------------------------------------------------------ wazuh
step "Installing the Wazuh rules and log sources"
RULES_BAK=$(mktemp -d)
for f in $RULE_FILES; do [ -e "$RULES_DIR/$f" ] && cp -p "$RULES_DIR/$f" "$RULES_BAK/$f"; done
cp -p "$OSSEC_CONF" "$RULES_BAK/ossec.conf"
write_file "$RULES_DIR/claude_rules.xml" 0660 root:wazuh <<'__EOF_rules_main__'
@@FILE:src/rules/claude_rules.xml@@
__EOF_rules_main__
write_file "$RULES_DIR/claude_security_rules.xml" 0660 root:wazuh <<'__EOF_rules_security__'
@@FILE:src/rules/claude_security_rules.xml@@
__EOF_rules_security__
write_file "$RULES_DIR/claude_usage_rules.xml" 0660 root:wazuh <<'__EOF_rules_usage__'
@@FILE:src/rules/claude_usage_rules.xml@@
__EOF_rules_usage__
write_file "$RULES_DIR/claude_dlp_rules.xml" 0660 root:wazuh <<'__EOF_rules_dlp__'
@@FILE:src/rules/claude_dlp_rules.xml@@
__EOF_rules_dlp__
ok "rules 101700-101836 in $RULES_DIR"

python3 - "$OSSEC_CONF" "$SYNC_DIR" $LOCALFILES <<'PY'
import sys
p, d, files = sys.argv[1], sys.argv[2], sys.argv[3:]
s = open(p).read()
add = ""
for f in files:
    loc = "%s/%s" % (d, f)
    if loc not in s:
        add += "\n  <localfile>\n    <log_format>json</log_format>\n    <location>%s</location>\n  </localfile>\n" % loc
if add:
    i = s.rindex("</ossec_config>")
    open(p, "w").write(s[:i].rstrip("\n") + "\n" + add + "\n" + s[i:])
    print("  added %d localfile block(s) to %s" % (add.count("<localfile>"), p))
else:
    print("  localfile blocks already present")
PY

if /var/ossec/bin/wazuh-analysisd -t >/tmp/claude-analysisd-test.log 2>&1; then ok "Wazuh accepts the rules and ossec.conf"
else
  cat /tmp/claude-analysisd-test.log >&2
  for f in $RULE_FILES; do if [ -e "$RULES_BAK/$f" ]; then cp -p "$RULES_BAK/$f" "$RULES_DIR/$f"; else rm -f "$RULES_DIR/$f"; fi; done
  cp -p "$RULES_BAK/ossec.conf" "$OSSEC_CONF"
  die "Wazuh rejected the configuration; the rules and ossec.conf were put back as they were"
fi

if [ "$YES" -eq 1 ] || [ -z "$TTY" ]; then a=y; else read -rp "Restart wazuh-manager now (needed to load the rules and log sources)? [Y/n] " a < "$TTY"; fi
if [ "${a:-y}" != n ] && [ "${a:-y}" != N ]; then systemctl restart wazuh-manager && ok "wazuh-manager restarted"
else warn "not restarted: run 'systemctl restart wazuh-manager' before the events can be rated"; fi

# ------------------------------------------------------------------------------------------------ indexer
step "Creating the alert-state index"
code=$(ix -o /dev/null -w '%{http_code}' -m 20 "$INDEXER_URL/$STATE_INDEX" || echo 000)
if [ "$code" = 200 ]; then ok "$STATE_INDEX already exists"; else
  out=$(ix -m 30 -X PUT -H 'Content-Type: application/json' "$INDEXER_URL/$STATE_INDEX" \
    -d '{"settings":{"number_of_shards":1,"number_of_replicas":0},"mappings":{"properties":{"status":{"type":"keyword"},"at":{"type":"long"},"by":{"type":"keyword"}}}}') || out=""
  echo "$out" | grep -q '"acknowledged":true' && ok "created $STATE_INDEX (alert acknowledge / close state)" || warn "could not create $STATE_INDEX: $out"
fi

# ------------------------------------------------------------------------------------------------ start
step "Starting the sync service"
systemctl daemon-reload
systemctl enable claude-sync >/dev/null 2>&1 || true
systemctl restart claude-sync
sleep 3
systemctl is-active --quiet claude-sync && ok "claude-sync is running" || { journalctl -u claude-sync -n 20 --no-pager >&2; die "claude-sync did not start"; }

step "Waiting for the first events to reach wazuh-alerts-* (up to 6 minutes)"
count_events() { ix -m 20 -X POST -H 'Content-Type: application/json' "$INDEXER_URL/wazuh-alerts-*/_search?ignore_unavailable=true&size=0" \
  -d '{"query":{"term":{"data.integration":"claude-enterprise"}},"aggs":{"feed":{"terms":{"field":"data.feed"}}}}' 2>/dev/null \
  | python3 -c 'import json,sys
try:
    d=json.load(sys.stdin); t=d["hits"]["total"]["value"]; f={b["key"]:b["doc_count"] for b in d["aggregations"]["feed"]["buckets"]}
    print(t, " ".join("%s=%s" % kv for kv in sorted(f.items())))
except Exception: print("0")' || echo 0; }
seen=""; for i in $(seq 1 36); do
  seen=$(count_events); n=${seen%% *}
  if [ "${n:-0}" -gt 0 ] 2>/dev/null; then break; fi
  printf '.'; sleep 10
done; echo
if [ "${seen%% *}" -gt 0 ] 2>/dev/null; then ok "events are in the indexer: ${seen}"
else warn "no Claude events in wazuh-alerts-* yet. Check: journalctl -u claude-sync -n 50 ; tail /var/ossec/logs/ossec.log ; filebeat/indexer health"; fi

cat <<EOF

${B}Done.${N}
  Service        systemctl status claude-sync        journalctl -u claude-sync -f
  Tunables       $ENV_DIR/env  (then: systemctl restart claude-sync)
  Compliance key systemctl edit $KEY_UNIT   ($KEY_TARGET), then: systemctl restart claude-sync
  Rules          $RULES_DIR/claude_*.xml
  Data buffers   $SYNC_DIR/claude_*.jsonl  (rotated daily; real data lives in wazuh-alerts-*)
  Alert state    index '$STATE_INDEX' in the indexer (no state files)
The first run back-fills what the Compliance API still holds; the content scan and usage feeds follow within a few minutes.
EOF
