#!/usr/bin/env bash
# =====================================================================================================================
# Claude Enterprise -> Wazuh sync: one-shot installer (everything up to the indexer; the dashboard is NOT included)
#
# What it sets up on a host that runs the Wazuh manager:
#   1. /opt/claude/claude_sync.py          the sync service (activities, token usage + spend, content scan)
#   2. claude-sync.service                 systemd unit. The Compliance key is stored ONCE, as Environment= of the
#                                          wazuh-dashboard unit (the equivalent of `systemctl edit wazuh-dashboard`,
#                                          file .../wazuh-dashboard.service.d/override.conf, mode 0600); the sync reads
#                                          it from there. Hosts without that unit get a claude-sync drop-in instead.
#   3. /var/ossec/etc/rules/claude_*.xml   Wazuh rules 101700-101836
#   4. three <localfile> blocks in /var/ossec/etc/ossec.conf (json files written by the sync)
#   5. a logrotate policy for the JSONL buffers
#   6. the claude-alert-state index in the indexer (alert acknowledge / close state, used by the dashboard later)
#   7. an end-to-end check: waits until the events show up in wazuh-alerts-*
#
# It asks for the Compliance API key and the indexer password (typed hidden). The key is written only to the systemd
# drop-in described above; the indexer password is never stored (used to verify the pipeline and create the state index).
#
# Usage:   sudo bash install-claude-sync.sh [--yes] [--uninstall] [--purge]
#   --yes        do not ask before restarting wazuh-manager
#   --insecure   do not verify the indexer's TLS certificate (also INDEXER_INSECURE=1). Without it the script verifies the
#                certificate and, if its host name does not match the URL (typical for https://127.0.0.1:9200), falls back to
#                skipping verification for the indexer only, with a warning.
#   --uninstall  stop and remove the service, rules, localfile blocks and logrotate policy (keeps data)
#   --purge      with --uninstall: also delete /opt/claude and /etc/claude-sync
# Non-interactive: export CLAUDE_COMPLIANCE_KEY, INDEXER_PASSWORD (and optionally INDEXER_URL, INDEXER_USER, INDEXER_CA).
# =====================================================================================================================
set -euo pipefail

YES=0; UNINSTALL=0; PURGE=0; INSECURE=${INDEXER_INSECURE:-0}
for a in "$@"; do
  case "$a" in
    --yes|-y) YES=1 ;; --insecure|-k) INSECURE=1 ;; --uninstall) UNINSTALL=1 ;; --purge) PURGE=1 ;;
    -h|--help) sed -n 2,26p "$0"; exit 0 ;;
    *) echo "unknown option: $a" >&2; exit 2 ;;
  esac
done

SYNC_DIR=/opt/claude
ENV_DIR=/etc/claude-sync
UNIT=/etc/systemd/system/claude-sync.service
DROPIN_DIR=/etc/systemd/system/claude-sync.service.d
WD_OVERRIDE=/etc/systemd/system/wazuh-dashboard.service.d/override.conf
RULES_DIR=/var/ossec/etc/rules
OSSEC_CONF=/var/ossec/etc/ossec.conf
STATE_INDEX=claude-alert-state
API_CHECK_URL="https://api.anthropic.com/v1/compliance/activities?limit=1"
RULE_FILES="claude_rules.xml claude_security_rules.xml claude_usage_rules.xml claude_dlp_rules.xml"
LOCALFILES="claude_activities.jsonl claude_usage.jsonl claude_content.jsonl"
STAMP=$(date +%Y%m%d-%H%M%S)

if [ -t 1 ]; then B=$'\e[1m'; G=$'\e[32m'; Y=$'\e[33m'; R=$'\e[31m'; N=$'\e[0m'; else B=; G=; Y=; R=; N=; fi
step() { echo; echo "${B}==> $*${N}"; }
ok()   { echo "  ${G}ok${N}  $*"; }
warn() { echo "  ${Y}warn${N} $*"; }
die()  { echo "  ${R}error${N} $*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "run as root (sudo bash $0)"
command -v systemctl >/dev/null || die "systemd is required"
command -v curl >/dev/null || die "curl is required"
command -v python3 >/dev/null || die "python3 is required"
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' || die "python3 >= 3.8 is required"
[ -x /var/ossec/bin/wazuh-control ] || die "Wazuh manager not found in /var/ossec (run this on the Wazuh manager host)"

# ------------------------------------------------------------------------------------------------ uninstall
if [ "$UNINSTALL" -eq 1 ]; then
  step "Uninstalling the Claude sync"
  systemctl disable --now claude-sync 2>/dev/null || true
  rm -f "$UNIT"; rm -rf "$DROPIN_DIR"
  if [ -f "$WD_OVERRIDE" ]; then python3 - "$WD_OVERRIDE" <<'PY'
import re, sys
p = sys.argv[1]; L = open(p).read().splitlines(True)
n = [l for l in L if not re.match(r'\s*Environment=\s*"?ANTHROPIC_COMPLIANCE_KEY=', l)]
if len(n) != len(L): open(p, "w").writelines(n)
PY
  fi
  systemctl daemon-reload
  for f in $RULE_FILES; do rm -f "$RULES_DIR/$f"; done
  rm -f /etc/logrotate.d/claude-sync
  python3 - "$OSSEC_CONF" "$STAMP" <<'PY'
import re, shutil, sys
p, stamp = sys.argv[1], sys.argv[2]
s = open(p).read()
n = re.sub(r"\n[ \t]*<localfile>\s*<log_format>json</log_format>\s*<location>/opt/claude/claude_(?:activities|usage|content)\.jsonl</location>\s*</localfile>[ \t]*", "", s)
if n != s:
    shutil.copy(p, p + ".bak-claude-" + stamp); open(p, "w").write(n)
PY
  if [ "$PURGE" -eq 1 ]; then rm -rf "$SYNC_DIR" "$ENV_DIR"; ok "removed $SYNC_DIR and $ENV_DIR"; else warn "kept $SYNC_DIR and $ENV_DIR (use --purge to delete)"; fi
  ok "removed. Restart wazuh-manager to unload the rules: systemctl restart wazuh-manager"
  exit 0
fi

# ------------------------------------------------------------------------------------------------ network (first check)
step "Checking that this server can reach the Anthropic API (api.anthropic.com:443)"
ANTHROPIC_HOST=api.anthropic.com
if [ -z "${HTTPS_PROXY:-}${https_proxy:-}" ] && command -v getent >/dev/null && ! getent hosts "$ANTHROPIC_HOST" >/dev/null 2>&1; then
  die "DNS: $ANTHROPIC_HOST does not resolve from this server. Check the VPC DNS settings (enableDnsSupport), the resolver in /etc/resolv.conf, or a private DNS zone."
fi
# Any HTTP answer (even 401/404 without a key) proves DNS, the TCP connection, TLS and the egress path all work.
net_code=$(curl -sS -o /dev/null -w '%{http_code}' --connect-timeout 10 -m 25 "https://$ANTHROPIC_HOST/v1/compliance/organizations" 2>/tmp/claude-net-check.err) && net_rc=0 || net_rc=$?
if [ "$net_rc" -ne 0 ]; then
  case "$net_rc" in
    6)  why="DNS: the name does not resolve." ;;
    7)  why="the connection was refused or reset on port 443." ;;
    28) why="the connection timed out. This is the typical sign of a firewall dropping outbound traffic: check the instance's Security Group (outbound rule for TCP 443), the subnet's Network ACL (outbound 443 and the inbound ephemeral ports 1024-65535), the route table (internet gateway or NAT gateway) and any proxy/egress filter." ;;
    35|51|58|60|77) why="TLS: the handshake or certificate check failed. A TLS-inspecting proxy or firewall is probably re-signing the traffic; install its CA certificate on this server." ;;
    5|56) why="the proxy refused or dropped the connection (check HTTPS_PROXY / NO_PROXY)." ;;
    *)  why="curl exit code $net_rc." ;;
  esac
  cat /tmp/claude-net-check.err >&2 2>/dev/null || true
  die "cannot reach https://$ANTHROPIC_HOST from this server: $why
        The sync only talks to this one host (HTTPS, port 443). Ask the network/AWS admin to allow outbound access, then run this script again.
        Quick test:  curl -v https://$ANTHROPIC_HOST/v1/compliance/organizations   (a 401 or 404 answer means the path is open)"
fi
ok "reached $ANTHROPIC_HOST (HTTP $net_code): DNS, port 443 and TLS work from this server"

# ------------------------------------------------------------------------------------------------ prompts
step "Settings"
if [ -t 0 ]; then TTY=/dev/stdin; elif { : </dev/tty; } 2>/dev/null; then TTY=/dev/tty; else TTY=""; fi
ask_secret() {  # ask_secret VAR "prompt"
  local var=$1 prompt=$2 v=""
  if [ -n "${!var:-}" ]; then return; fi
  [ -n "$TTY" ] || die "$var is not set and there is no terminal to ask on (export $var=... and run again)"
  while [ -z "$v" ]; do read -rsp "$prompt: " v < "$TTY"; echo >&2; done
  printf -v "$var" '%s' "$v"
}
ask() {  # ask VAR "prompt" default
  local var=$1 prompt=$2 def=$3 v=""
  if [ -n "${!var:-}" ]; then return; fi
  if [ -n "$TTY" ]; then read -rp "$prompt [$def]: " v < "$TTY"; fi
  printf -v "$var" '%s' "${v:-$def}"
}
CLAUDE_COMPLIANCE_KEY=${CLAUDE_COMPLIANCE_KEY:-}; INDEXER_PASSWORD=${INDEXER_PASSWORD:-}
INDEXER_URL=${INDEXER_URL:-}; INDEXER_USER=${INDEXER_USER:-}
ask_secret CLAUDE_COMPLIANCE_KEY "Anthropic Compliance API key"
ask INDEXER_URL "Wazuh indexer URL" "https://127.0.0.1:9200"
ask INDEXER_USER "Wazuh indexer user" "admin"
ask_secret INDEXER_PASSWORD "Wazuh indexer password for '$INDEXER_USER'"
INDEXER_URL=${INDEXER_URL%/}
INDEXER_CA=${INDEXER_CA:-/etc/wazuh-indexer/certs/root-ca.pem}
if [ "$INSECURE" -eq 1 ]; then CA_OPT=(-k); elif [ -r "$INDEXER_CA" ]; then CA_OPT=(--cacert "$INDEXER_CA"); else CA_OPT=(-k); fi

# curl with the password kept off the command line (it would show in ps)
cfg_escape() { local s=$1; s=${s//\\/\\\\}; s=${s//\"/\\\"}; printf '%s' "$s"; }
ix() { curl -sS "${CA_OPT[@]}" -K <(printf 'user = "%s"\n' "$(cfg_escape "$INDEXER_USER:$INDEXER_PASSWORD")") "$@"; }

# ------------------------------------------------------------------------------------------------ checks
step "Checking the Compliance API key"
code=$(curl -sS -o /dev/null -w '%{http_code}' -m 30 -K <(printf 'header = "x-api-key: %s"\n' "$(cfg_escape "$CLAUDE_COMPLIANCE_KEY")") \
       -H "anthropic-version: 2023-06-01" "$API_CHECK_URL" 2>/dev/null) || code=000
case "$code" in
  200) ok "the Compliance API accepted the key" ;;
  401|403|404) die "the Compliance API rejected the key (HTTP $code; Anthropic answers 404 for an unknown key). Check the key and that it has the read:compliance_activities scope" ;;
  000) warn "could not reach api.anthropic.com (network or proxy?)"; [ "$YES" -eq 1 ] || { [ -n "$TTY" ] || exit 1; read -rp "  continue anyway? [y/N] " a < "$TTY"; [ "${a,,}" = y ] || exit 1; } ;;
  *) warn "unexpected HTTP $code from the Compliance API"; [ "$YES" -eq 1 ] || { [ -n "$TTY" ] || exit 1; read -rp "  continue anyway? [y/N] " a < "$TTY"; [ "${a,,}" = y ] || exit 1; } ;;
esac

step "Checking the Wazuh indexer"
code=$(ix -o /dev/null -w '%{http_code}' -m 20 "$INDEXER_URL/" 2>/tmp/claude-ix.err) && rc=0 || rc=$?
if [ "$rc" -ne 0 ] && [ "${CA_OPT[0]}" != -k ]; then
  case "$rc" in
    51|58|60|77)   # certificate does not match the host name / unknown CA: expected for https://127.0.0.1 with a node-name certificate
      warn "the indexer's TLS certificate could not be verified ($(tr -d '\n' </tmp/claude-ix.err | cut -c1-110))"
      warn "continuing WITHOUT certificate verification for the indexer only (credentials go to $INDEXER_URL; use --insecure to skip this probe)"
      CA_OPT=(-k)
      code=$(ix -o /dev/null -w '%{http_code}' -m 20 "$INDEXER_URL/" 2>/tmp/claude-ix.err) && rc=0 || rc=$? ;;
  esac
fi
[ "$rc" -eq 0 ] || code=000
case "$code" in
  200) ok "indexer reachable, credentials accepted" ;;
  401) die "the indexer rejected the user/password" ;;
  *) die "the indexer at $INDEXER_URL did not answer (HTTP $code, curl exit $rc): $(cat /tmp/claude-ix.err 2>/dev/null | tr -d '\n' | cut -c1-200)" ;;
esac
ix -m 20 "$INDEXER_URL/_cat/indices/wazuh-alerts-*?h=index" | head -1 | grep -q wazuh-alerts && ok "wazuh-alerts-* indices exist" \
  || warn "no wazuh-alerts-* index yet (it is created when the first alert arrives)"

if ! command -v pdftotext >/dev/null; then
  warn "pdftotext not found: PDFs will not be content-scanned. Install poppler-utils (apt) or poppler-utils (dnf/yum) to enable it."
fi

# ------------------------------------------------------------------------------------------------ files
step "Installing the sync service"
GRP=root; getent group wazuh >/dev/null && GRP=wazuh
install -d -m 2750 -o root -g "$GRP" "$SYNC_DIR"
install -d -m 0750 -o root -g root "$ENV_DIR"
write_file() {  # write_file path mode owner:group  (content on stdin)
  local path=$1 mode=$2 own=$3 tmp; tmp=$(mktemp)
  cat > "$tmp"
  if [ -e "$path" ] && ! cmp -s "$tmp" "$path"; then cp -p "$path" "$path.bak-$STAMP"; fi
  install -m "$mode" -o "${own%%:*}" -g "${own##*:}" "$tmp" "$path"; rm -f "$tmp"
}
write_file "$SYNC_DIR/claude_sync.py" 0750 root:$GRP <<'__EOF_claude_sync_py__'
#!/usr/bin/env python3
"""
Claude Enterprise Compliance API -> JSONL sync service
=======================================================
Pulls the organization Activity Feed (GET /v1/compliance/activities) and, from the same service, per-user token usage and
spend limits and a sensitive data scan of chat content (see the collectors below). Activities: appends
every event as one JSON line to /opt/claude/claude_activities.jsonl, ready for a
Wazuh localfile (log_format json) in a later step.

Design (follows Anthropic's "Design your compliance integration" guidance):
  - Cursor-driven incremental reads (before_id = first_id) so each run only fetches new events.
  - First run backfills everything the feed holds (recording started when the API was enabled).
  - Every run also re-reads a recent window (ends 2 minutes in the past) to catch late-indexed events.
  - Delivery is at-least-once, so events are de-duplicated on the activity "id".
  - The cursor is saved only after the page it covers has been written and fsynced.
  - Read-only: only GET requests are made, and only to the Activity Feed.

Run:
  python3 claude_sync.py --once     # single sync, then exit
  python3 claude_sync.py            # loop, every CLAUDE_SYNC_INTERVAL seconds (default 300)

Environment:
  ANTHROPIC_COMPLIANCE_KEY   Compliance Access Key (scope read:compliance_activities is enough)
  CLAUDE_SYNC_INTERVAL       seconds between runs (default 300)
  CLAUDE_SYNC_DIR            output directory (default /opt/claude)
  CLAUDE_SYNC_PAGE_LIMIT     events per request, 1-5000 (default 1000)
"""

import argparse
import fcntl
import ipaddress
import json
import logging
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

API_URL = "https://api.anthropic.com/v1/compliance/activities"
API_VERSION = "2023-06-01"

BASE_DIR = Path(os.environ.get("CLAUDE_SYNC_DIR", "/opt/claude"))
EVENTS_FILE = BASE_DIR / "claude_activities.jsonl"
STATE_FILE = BASE_DIR / "state.json"
LOCK_FILE = BASE_DIR / "sync.lock"

KEY_UNIT = os.environ.get("CLAUDE_KEY_UNIT", "wazuh-dashboard")   # systemd unit whose Environment= holds the key (systemctl edit wazuh-dashboard)


def load_api_key():
    """The Compliance key lives in one place: Environment="ANTHROPIC_COMPLIANCE_KEY=..." of the wazuh-dashboard unit.
    An ANTHROPIC_COMPLIANCE_KEY in this process's own environment wins (for tests and for hosts without that unit)."""
    k = os.environ.get("ANTHROPIC_COMPLIANCE_KEY", "")
    if k or not KEY_UNIT:
        return k
    try:
        import shlex
        import subprocess as sp
        out = sp.run(["systemctl", "show", KEY_UNIT, "--property=Environment", "--value"], capture_output=True, text=True, timeout=15).stdout
        for tok in shlex.split(out):
            if tok.startswith("ANTHROPIC_COMPLIANCE_KEY="):
                return tok.split("=", 1)[1]
    except Exception:
        pass
    return ""


API_KEY = load_api_key()
INTERVAL = int(os.environ.get("CLAUDE_SYNC_INTERVAL", "300"))
PAGE_LIMIT = max(1, min(int(os.environ.get("CLAUDE_SYNC_PAGE_LIMIT", "1000")), 5000))

HEARTBEAT_SECONDS = int(os.environ.get("CLAUDE_HEARTBEAT_SECONDS", "0"))  # 0 = one status line per run (Integration Health)
ORGS_URL = "https://api.anthropic.com/v1/compliance/organizations"
ORGS_REFRESH_SECONDS = 6 * 3600
RATE = {}                   # last rate-limit headers seen (anthropic-ratelimit-requests-*)
RUN = {}                    # per-run counters, reset at the start of every sync_once()

RECONCILE_WINDOW_MIN = 15   # re-read this much recent history every run
LAG_SECONDS = 120           # events are queryable ~1 minute after they happen; keep a margin
SEEN_MAX = 20000            # de-duplication memory (activity ids)
REQUEST_TIMEOUT = 60

# security flags (rules 101801-101821): the sync remembers every actor between runs
WORK_HOURS = os.environ.get("CLAUDE_WORK_HOURS_UTC", "03-15")    # "start-end" UTC hours, end exclusive; empty switches off_hours off
WORK_DAYS = os.environ.get("CLAUDE_WORK_DAYS", "1-6")            # ISO weekdays, 1 = Monday ... 7 = Sunday
DORMANT_DAYS = int(os.environ.get("CLAUDE_DORMANT_DAYS", "30"))  # days without activity before a return is flagged
ACTORS_MAX = 5000
IPS_PER_ACTOR = 30

os.umask(0o027)  # files: rw-r----- (group wazuh can read)

logging.basicConfig(stream=sys.stdout, level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("claude_sync")


class ApiError(Exception):
    def __init__(self, status, message):
        super().__init__(f"HTTP {status}: {message}")
        self.status = status


# ---------------------------------------------------------------- state
def load_state():
    try:
        with open(STATE_FILE) as f:
            return json.load(f)
    except FileNotFoundError:
        return {"cursor": None, "seen": [], "total_written": 0}
    except json.JSONDecodeError:
        log.error("state.json is corrupt; starting over (de-duplication is lost, duplicates are possible)")
        return {"cursor": None, "seen": [], "total_written": 0}


def save_state(state):
    state["seen"] = state["seen"][-SEEN_MAX:]
    if len(state.get("actors") or {}) > ACTORS_MAX:
        keep = sorted(state["actors"].items(), key=lambda kv: kv[1].get("last", ""))[-ACTORS_MAX:]
        state["actors"] = dict(keep)
    tmp = STATE_FILE.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(state, f)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, STATE_FILE)


# ---------------------------------------------------------------- API
def fetch(params):
    """GET one page of the Activity Feed. Retries 429 / 5xx / network errors."""
    url = API_URL + "?" + urllib.parse.urlencode(params, doseq=True)
    req = urllib.request.Request(url, headers={
        "x-api-key": API_KEY,
        "anthropic-version": API_VERSION,
        "user-agent": "athena-claude-sync/1.0",
    })
    last = None
    for attempt in range(1, 5):
        RUN["requests"] = RUN.get("requests", 0) + 1
        try:
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
                RUN["http_status"] = resp.status
                for name, key in (("anthropic-ratelimit-requests-limit", "limit"),
                                  ("anthropic-ratelimit-requests-remaining", "remaining"),
                                  ("anthropic-ratelimit-requests-reset", "reset")):
                    if resp.headers.get(name) is not None:
                        RATE[key] = resp.headers.get(name)
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            RUN["http_status"] = e.code
            body = e.read().decode("utf-8", "replace")[:300]
            if e.code == 429:
                wait = int(e.headers.get("retry-after", "30") or 30)
                log.warning("rate limited (429), waiting %ss", wait)
                time.sleep(min(wait, 120))
                last = ApiError(429, body)
            elif e.code >= 500:
                log.warning("server error %s, retry %s/4", e.code, attempt)
                time.sleep(2 ** attempt)
                last = ApiError(e.code, body)
            else:
                raise ApiError(e.code, body)  # 400/401/403/404: do not retry
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            log.warning("network error (%s), retry %s/4", e, attempt)
            time.sleep(2 ** attempt)
            last = ApiError(0, str(e))
    raise last


# ---------------------------------------------------------------- security flags
def _ts(value):
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def _rng(spec, lo, hi):
    try:
        a, b = (int(x) for x in str(spec).split("-"))
        return max(lo, a), min(hi, b)
    except ValueError:
        return None


def outside_work_window(dt):
    hrs, days = _rng(WORK_HOURS, 0, 24), _rng(WORK_DAYS, 1, 7)
    if not hrs or not days:
        return False
    return not (days[0] <= dt.isoweekday() <= days[1] and hrs[0] <= dt.hour < hrs[1])


def ip_key(ip):
    """IPv6 privacy addresses rotate inside one /64, so an IPv6 address is compared by its /64 network."""
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return ip
    if addr.is_unspecified or addr.is_loopback:   # 0.0.0.0 and ::1 carry no location (internal clients such as artifacts)
        return None
    return str(ipaddress.ip_network(str(addr) + "/64", strict=False)) if addr.version == 6 else str(addr)


def track_actor(ev, actors, flag=True):
    """Remember the actor; when flag is true, add new_ip_for_actor / off_hours / dormant_days to the event."""
    a = ev.get("actor") or {}
    key = a.get("email_address") or a.get("user_id") or a.get("api_key_id")
    if not key or str(a.get("user_agent", "")).startswith("athena-claude-sync"):
        return
    created = ev.get("created_at") or ""
    dt = _ts(created)
    rec = actors.get(key)
    chronological = bool(rec) and bool(dt) and created >= rec.get("last", "")
    ip = ip_key(a["ip_address"]) if a.get("ip_address") else None   # None for a missing or unspecified address
    if ip:
        if rec and rec["ips"] and ip not in rec["ips"] and chronological and flag:
            ev["new_ip_for_actor"] = True
        if rec is None:
            rec = actors[key] = {"ips": [], "last": ""}
        if ip not in rec["ips"]:
            rec["ips"] = (rec["ips"] + [ip])[-IPS_PER_ACTOR:]
    elif rec is None:
        rec = actors[key] = {"ips": [], "last": ""}
    if flag and a.get("type") == "user_actor" and dt:
        last = _ts(rec.get("last"))
        if last and chronological and DORMANT_DAYS > 0 and (dt - last).days >= DORMANT_DAYS:
            ev["dormant_days"] = (dt - last).days
        etype = str(ev.get("type", ""))
        if not etype.endswith("_viewed") and etype != "compliance_api_accessed" and outside_work_window(dt):
            ev["off_hours"] = True
    if created > rec.get("last", ""):
        rec["last"] = created


def get_actors(state):
    """Actor memory; the first time it is built from the events already on disk (nothing is flagged for old events)."""
    actors = state.get("actors")
    if actors is None:
        actors = state["actors"] = {}
        import glob
        import gzip
        files = sorted(glob.glob(str(EVENTS_FILE) + "-*")) + [str(EVENTS_FILE)]
        for fn in files:
            try:
                opener = gzip.open if fn.endswith(".gz") else open
                with opener(fn, "rt", encoding="utf-8") as f:
                    for line in f:
                        try:
                            track_actor(json.loads(line), actors, flag=False)
                        except ValueError:
                            continue
            except OSError:
                continue
        log.info("actor memory built from %d file(s): %d actors", len(files), len(actors))
    return actors


# ---------------------------------------------------------------- output
def write_page(events, state):
    """Append unseen events (oldest first) to the JSONL file. Returns number written."""
    seen = set(state["seen"])
    new = []
    for ev in reversed(events):  # API returns newest first
        eid = ev.get("id")
        if eid and eid in seen:
            RUN["dedup"] = RUN.get("dedup", 0) + 1
            continue
        a0 = ev.get("actor") or {}
        if ev.get("type") == "compliance_api_accessed" and str(a0.get("user_agent", "")).startswith("athena-claude-sync") and a0.get("api_key_id"):
            state["own_key_id"] = a0["api_key_id"]
        new.append(ev)
        # newest real activity (our own polls excluded) for the Integration Health screen
        c = ev.get("created_at") or ""
        if ev.get("id") and c >= state.get("newest_at", "") and not (ev.get("type") == "compliance_api_accessed" and str(a0.get("user_agent", "")).startswith("athena-claude-sync")):
            state["newest_at"] = c
            state["newest_id"] = ev["id"]
    if new:
        actors = get_actors(state)
        for ev in new:
            track_actor(ev, actors)
        with open(EVENTS_FILE, "a", encoding="utf-8") as f:
            for ev in new:
                ev["integration"] = "claude-enterprise"
                ev["feed"] = "activity"
                # Wazuh enrichment aliases: srcip gives GeoLocation, srcuser fills the user column.
                actor = ev.get("actor") or {}
                if actor.get("ip_address"):
                    ev["srcip"] = actor["ip_address"]
                who = actor.get("email_address") or actor.get("unauthenticated_email_address")
                if who:
                    ev["srcuser"] = who
                f.write(json.dumps(ev, separators=(",", ":"), ensure_ascii=False) + "\n")
            f.flush()
            os.fsync(f.fileno())
        for ev in new:
            if ev.get("id"):
                state["seen"].append(ev["id"])
        state["total_written"] = state.get("total_written", 0) + len(new)
    return len(new)


def refresh_orgs(state):
    """Organization names for the dashboard (cached; the feed carries ids only). Fails soft."""
    last = state.get("orgs_at")
    if last and state.get("orgs") and (time.time() - last) < ORGS_REFRESH_SECONDS:
        return
    try:
        req = urllib.request.Request(ORGS_URL, headers={"x-api-key": API_KEY, "anthropic-version": API_VERSION,
                                                        "user-agent": "athena-claude-sync/1.0"})
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode("utf-8")).get("data", [])
        state["orgs"] = "|".join("%s:%s" % (o.get("uuid", ""), str(o.get("name", "")).replace("|", "/").replace(":", " -")) for o in data)
        state["orgs_at"] = time.time()
    except Exception as e:  # keep the old value, try again next run
        log.warning("organizations lookup failed: %s", e)


def write_heartbeat(state, status, new_events=0, error=None):
    """One status line per HEARTBEAT_SECONDS (or immediately when the status changes) for the Integration Health screen."""
    now = datetime.now(timezone.utc)
    last = state.get("last_heartbeat")
    if last and state.get("last_heartbeat_status") == status \
            and (now - datetime.fromisoformat(last)).total_seconds() < HEARTBEAT_SECONDS:
        return
    sync = {"status": status, "interval_seconds": INTERVAL, "new_events": new_events,
            "total_written": state.get("total_written", 0),
            "requests": RUN.get("requests", 0), "dedup": RUN.get("dedup", 0),
            "duration_ms": int((time.time() - RUN.get("started", time.time())) * 1000)}
    if RUN.get("http_status") is not None:
        sync["http_status"] = RUN["http_status"]
    if state.get("cursor"):
        sync["cursor_tail"] = state["cursor"][-12:]
    if state.get("newest_id"):
        sync["newest_id"] = state["newest_id"]
        sync["newest_at"] = state.get("newest_at", "")
    if state.get("own_key_id"):
        sync["own_key_id"] = state["own_key_id"]
    if state.get("orgs"):
        sync["orgs"] = state["orgs"]
    if state.get("last_success"):
        sync["last_success"] = state["last_success"]
    for k in ("limit", "remaining", "reset"):
        if RATE.get(k) is not None:
            sync["rate_limit_" + k] = RATE[k]
    if error:
        sync["error"] = error
    hb = {"id": "heartbeat_" + now.strftime("%Y%m%dT%H%M%S"),
          "created_at": now.strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
          "type": "athena_sync_heartbeat", "integration": "claude-enterprise", "feed": "activity", "sync": sync}
    with open(EVENTS_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(hb, separators=(",", ":")) + "\n")
        f.flush()
        os.fsync(f.fileno())
    state["last_heartbeat"] = now.isoformat()
    state["last_heartbeat_status"] = status


# ---------------------------------------------------------------- sync
def backfill(state):
    """First run: walk from newest to oldest (after_id), then store the newest first_id as the cursor."""
    written = 0
    page = fetch({"limit": PAGE_LIMIT})
    newest_first_id = page.get("first_id")
    while True:
        written += write_page(page.get("data", []), state)
        if not page.get("has_more") or not page.get("last_id"):
            break
        page = fetch({"limit": PAGE_LIMIT, "after_id": page["last_id"]})
    if newest_first_id:
        state["cursor"] = newest_first_id
    save_state(state)
    return written


def incremental(state):
    """Fetch everything newer than the stored cursor, one adjacent page at a time."""
    written = 0
    while True:
        page = fetch({"limit": PAGE_LIMIT, "before_id": state["cursor"]})
        written += write_page(page.get("data", []), state)
        if page.get("first_id"):
            state["cursor"] = page["first_id"]
        save_state(state)  # cursor moves only after the page above is written
        if not page.get("has_more"):
            break
    return written


def reconcile(state):
    """Re-read the recent window to pick up late-indexed events; de-duplication drops the rest."""
    now = datetime.now(timezone.utc)
    params = {
        "limit": PAGE_LIMIT,
        "created_at.gte": (now - timedelta(minutes=RECONCILE_WINDOW_MIN)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "created_at.lt": (now - timedelta(seconds=LAG_SECONDS)).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    written = 0
    page = fetch(params)
    while True:
        written += write_page(page.get("data", []), state)
        if not page.get("has_more") or not page.get("last_id"):
            break
        page = fetch({**params, "after_id": page["last_id"]})
    save_state(state)
    return written


def sync_once():
    state = load_state()
    started = time.time()
    RUN.clear()
    RUN["started"] = started
    try:
        if state.get("cursor") is None:
            log.info("no cursor yet: running initial backfill")
            n_main = backfill(state)
        else:
            n_main = incremental(state)
        n_rec = reconcile(state)
        state["last_success"] = datetime.now(timezone.utc).isoformat()
        state["last_error"] = None
        state["last_new_events"] = n_main + n_rec
        refresh_orgs(state)
        write_heartbeat(state, "ok", n_main + n_rec)
        save_state(state)
        log.info("sync ok: %d new events (%d from cursor, %d from reconcile), %d total written, %.1fs",
                 n_main + n_rec, n_main, n_rec, state.get("total_written", 0), time.time() - started)
        return True
    except ApiError as e:
        state["last_error"] = {"at": datetime.now(timezone.utc).isoformat(), "error": str(e)}
        write_heartbeat(state, "error", error=str(e)[:200])
        save_state(state)
        if e.status in (401, 403):
            log.error("authentication/permission problem: %s (check the key and its read:compliance_activities scope)", e)
        else:
            log.error("sync failed: %s", e)
        return False


# =====================================================================================================
# TOKEN USAGE AND SPEND COLLECTOR (Claude Enterprise Analytics API + Spend Limits API)
# Runs inside this same service, every CLAUDE_USAGE_INTERVAL seconds (default 600). Anthropic refreshes the
# usage report about every 4 hours, so there is no point polling it every minute. Output: claude_usage.jsonl.
# A failure here never stops the activity collector above, and the other way round.
# =====================================================================================================
USAGE_API_URL = "https://api.anthropic.com/v1/organizations/analytics/user_usage_report"
USAGE_OUT_FILE = BASE_DIR / "claude_usage.jsonl"
USAGE_STATE_FILE = BASE_DIR / "usage_state.json"
USAGE_INTERVAL = int(os.environ.get("CLAUDE_USAGE_INTERVAL", "600"))
USAGE_ENABLED = os.environ.get("CLAUDE_USAGE_ENABLED", "1") != "0"
WINDOW_HOURS = int(os.environ.get("CLAUDE_USAGE_WINDOW_HOURS", "48"))
BACKFILL_DAYS = max(1, min(int(os.environ.get("CLAUDE_USAGE_BACKFILL_DAYS", "14")), 31))
USAGE_PAGE_LIMIT = 1000
SPEND_URL = "https://api.anthropic.com/v1/organizations/spend_limits/effective"

KEEP_DAYS = 9               # buckets kept in state (covers day sums and late revisions)
ALERT_WINDOW_HOURS = 48     # thresholds are only raised for windows that ended within this time

THRESHOLDS = {}
for scope in ("USER_DAY", "USER_HOUR", "ORG_DAY"):
    for level in ("WARN", "CRIT"):
        THRESHOLDS[(scope.lower(), "warn" if level == "WARN" else "critical")] = int(
            os.environ.get("CLAUDE_TOKEN_%s_%s" % (scope, level), "0") or 0)

# What the limits count: "fresh" = new input + cache creation + output (new text); "total" also counts cache reads,
# which are the earlier conversation re-read on every message and make long chats look huge.
BASIS = os.environ.get("CLAUDE_TOKEN_BASIS", "fresh").strip().lower()
if BASIS not in ("fresh", "total"):
    BASIS = "fresh"
METRIC = "fresh_tokens" if BASIS == "fresh" else "total_tokens"

SPEND_WARN_PCT = float(os.environ.get("CLAUDE_SPEND_WARN_PCT", "80") or 0)    # alert when a member has used this % of their monthly spend limit
SPEND_CRIT_PCT = float(os.environ.get("CLAUDE_SPEND_CRIT_PCT", "100") or 0)   # 0 switches a level off

SPIKE_FACTOR = float(os.environ.get("CLAUDE_TOKEN_SPIKE_FACTOR", "0") or 0)   # hour total vs the user's own hourly average; 0 = off
SPIKE_MIN = int(os.environ.get("CLAUDE_TOKEN_SPIKE_MIN", "1000000") or 0)      # ignore spikes smaller than this many tokens
SPIKE_HISTORY_HOURS = 6                                                          # hours of history needed before a baseline exists

URUN = {}




def iso(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def usage_load_state():
    try:
        with open(USAGE_STATE_FILE) as f:
            return json.load(f)
    except FileNotFoundError:
        return {"buckets": {}, "alerted": {}, "total_written": 0}
    except json.JSONDecodeError:
        log.error("usage_state.json is corrupt; starting over (buckets will be written again)")
        return {"buckets": {}, "alerted": {}, "total_written": 0}


def usage_save_state(state):
    tmp = USAGE_STATE_FILE.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(state, f)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, USAGE_STATE_FILE)


def usage_fetch(params, base=None):
    url = (base or USAGE_API_URL) + "?" + urllib.parse.urlencode(params, doseq=True)
    req = urllib.request.Request(url, headers={"x-api-key": API_KEY, "anthropic-version": API_VERSION,
                                               "user-agent": "athena-claude-sync/1.0"})
    last = None
    for attempt in range(1, 5):
        URUN["requests"] = URUN.get("requests", 0) + 1
        try:
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
                URUN["http_status"] = resp.status
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            URUN["http_status"] = e.code
            body = e.read().decode("utf-8", "replace")[:300]
            if e.code == 429:
                time.sleep(min(int(e.headers.get("retry-after", "30") or 30), 120))
                last = ApiError(429, body)
            elif e.code >= 500:
                time.sleep(2 ** attempt)
                last = ApiError(e.code, body)
            else:
                raise ApiError(e.code, body)
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            time.sleep(2 ** attempt)
            last = ApiError(0, str(e))
    raise last


def usage_fetch_all(start, end):
    """All hourly rows from `start` to `end` (UTC datetimes), split by user x product x model."""
    params = {"starting_at": iso(start), "ending_at": iso(end), "bucket_width": "1h", "limit": USAGE_PAGE_LIMIT,
              "group_by[]": ["model", "product"], "order_by": "total_tokens", "order": "desc"}
    rows, refreshed = [], None
    while True:
        page = usage_fetch(params)
        rows.extend(page.get("data", []))
        refreshed = page.get("data_refreshed_at") or refreshed
        if not page.get("has_more") or not page.get("next_page"):
            break
        params["page"] = page["next_page"]
    return rows, refreshed


def usage_values(row):
    cc = row.get("cache_creation") or {}
    return {
        "total_tokens": int(row.get("total_tokens") or 0),
        "uncached_input_tokens": int(row.get("uncached_input_tokens") or 0),
        "output_tokens": int(row.get("output_tokens") or 0),
        "cache_read_input_tokens": int(row.get("cache_read_input_tokens") or 0),
        "cache_creation_input_tokens": int(cc.get("ephemeral_1h_input_tokens") or 0) + int(cc.get("ephemeral_5m_input_tokens") or 0),
        "requests": int(row.get("requests") or 0),
        "web_search_requests": int((row.get("server_tool_use") or {}).get("web_search_requests") or 0),
    }


def usage_fresh_of(v):
    return v["uncached_input_tokens"] + v["cache_creation_input_tokens"] + v["output_tokens"]


def usage_append(lines):
    if not lines:
        return
    with open(USAGE_OUT_FILE, "a", encoding="utf-8") as f:
        for ln in lines:
            f.write(json.dumps(ln, separators=(",", ":"), ensure_ascii=False) + "\n")
        f.flush()
        os.fsync(f.fileno())


def usage_write_buckets(rows, state):
    """Write every bucket that is new or whose numbers changed. Returns (lines written, rows seen)."""
    out = []
    for r in rows:
        actor = r.get("actor") or {}
        start = r.get("starting_at")
        if not start or not actor.get("user_id"):
            continue
        v = usage_values(r)
        key = "|".join([actor["user_id"], start, str(r.get("product")), str(r.get("model"))])
        v["fresh_tokens"] = usage_fresh_of(v)
        fingerprint = [v["total_tokens"], v["output_tokens"], v["requests"], v["cache_read_input_tokens"], v["uncached_input_tokens"], v["fresh_tokens"]]
        prev = state["buckets"].get(key)
        if prev and prev["fp"] == fingerprint:
            continue
        state["buckets"][key] = {"fp": fingerprint, "u": actor["user_id"], "e": actor.get("email_address"), "s": start,
                                 "t": v["total_tokens"], "f": v["fresh_tokens"]}
        line = {"integration": "claude-enterprise", "feed": "usage", "type": "claude_usage", "id": key,
                "usage": {"user_id": actor["user_id"], "email": actor.get("email_address"), "name": actor.get("name"),
                          "deleted": bool(actor.get("deleted")), "product": r.get("product"), "model": r.get("model"),
                          "starting_at": start, "ending_at": r.get("ending_at"), **v}}
        if actor.get("email_address"):
            line["srcuser"] = actor["email_address"]
        out.append(line)
    usage_append(out)
    state["total_written"] = state.get("total_written", 0) + len(out)
    return len(out), len(rows)


def usage_fetch_spend():
    """Every member's monthly spend limit and month-to-date spend (the numbers claude.ai shows as "$5.40 of $20.00 spent")."""
    params, rows = {"limit": 100}, []
    while True:
        page = usage_fetch(params, SPEND_URL)
        rows.extend(page.get("data", []))
        if not page.get("next_page"):
            break
        params["page"] = page["next_page"]
    return rows


def usage_write_spend(rows, state, now):
    """One claude_spend line when a member's spend or limit changed, and a threshold line when a % of the limit is first reached."""
    seen = state.setdefault("spend", {})
    month = now.strftime("%Y-%m")
    out, alerts = [], []
    for r in rows:
        actor = r.get("actor") or {}
        uid = actor.get("user_id") or (r.get("scope") or {}).get("user_id")
        if not uid:
            continue
        try:
            limit, spent = float(r.get("amount") or 0), float(r.get("period_to_date_spend") or 0)
        except ValueError:
            continue
        fp = [round(spent, 3), round(limit, 3), month]
        if seen.get(uid) != fp:
            seen[uid] = fp
            line = {"integration": "claude-enterprise", "feed": "usage", "type": "claude_spend", "id": "sp|%s|%s" % (uid, iso(now)),
                    "spend": {"user_id": uid, "email": actor.get("email_address"), "name": actor.get("name"), "currency": r.get("currency"),
                              "period": r.get("period"), "month": month, "limit_cents": round(limit, 2), "spent_cents": round(spent, 2),
                              "percent": round(100.0 * spent / limit, 1) if limit > 0 else None,
                              "source": (r.get("source") or {}).get("seat_tier") or (r.get("source") or {}).get("type")}}
            if actor.get("email_address"):
                line["srcuser"] = actor["email_address"]
            out.append(line)
        if limit > 0:
            pct = 100.0 * spent / limit
            level = "critical" if SPEND_CRIT_PCT and pct >= SPEND_CRIT_PCT else "warn" if SPEND_WARN_PCT and pct >= SPEND_WARN_PCT else None
            if level:
                akey = "user_spend|%s|%s" % (uid, month)
                rank = 2 if level == "critical" else 1
                if state["alerted"].get(akey, {}).get("r", 0) < rank:
                    state["alerted"][akey] = {"r": rank, "w": month + "-01"}
                    alerts.append({"integration": "claude-enterprise", "feed": "usage", "type": "claude_token_threshold", "id": "th|%s|%s" % (akey, level),
                                   "threshold": {"scope": "user_spend", "level": level, "metric": "spend_cents", "window": month,
                                                 "limit": round(limit * (SPEND_CRIT_PCT if level == "critical" else SPEND_WARN_PCT) / 100.0, 2),
                                                 "value": round(spent, 2), "percent_of_limit": round(pct), "user_id": uid, "email": actor.get("email_address")},
                                   **({"srcuser": actor["email_address"]} if actor.get("email_address") else {})})
    usage_append(out + alerts)
    state["total_written"] = state.get("total_written", 0) + len(out) + len(alerts)
    return len(out), len(alerts)


def usage_prune(state, now):
    cut = iso(now - timedelta(days=KEEP_DAYS))
    state["buckets"] = {k: b for k, b in state["buckets"].items() if b["s"] >= cut}
    state["alerted"] = {k: v for k, v in state["alerted"].items() if v.get("w", "") >= cut[:10]}


def usage_evaluate_thresholds(state, now):
    """Sum the stored buckets and raise one alert per window the first time a limit is reached."""
    user_hour, user_day, org_day, emails = {}, {}, {}, {}
    for b in state["buckets"].values():
        u, s = b["u"], b["s"]
        t = b.get("f") if BASIS == "fresh" else b["t"]
        if t is None:      # bucket stored before fresh tokens were tracked
            continue
        emails[u] = b.get("e") or emails.get(u)
        user_hour[(u, s)] = user_hour.get((u, s), 0) + t
        user_day[(u, s[:10])] = user_day.get((u, s[:10]), 0) + t
        org_day[s[:10]] = org_day.get(s[:10], 0) + t
    horizon = iso(now - timedelta(hours=ALERT_WINDOW_HOURS))
    cases = []
    for (u, s), t in user_hour.items():
        if s >= horizon:
            cases.append(("user_hour", u, s, t))
    for (u, d), t in user_day.items():
        if d + "T23:59:59Z" >= horizon:
            cases.append(("user_day", u, d, t))
    for d, t in org_day.items():
        if d + "T23:59:59Z" >= horizon:
            cases.append(("org_day", None, d, t))
    # hourly spike against the user's own baseline (average of their earlier active hours)
    if SPIKE_FACTOR > 0:
        by_user = {}
        for (u, s), t in user_hour.items():
            by_user.setdefault(u, []).append((s, t))
        for u, hours in by_user.items():
            for s, t in hours:
                if s < horizon or t < SPIKE_MIN:
                    continue
                earlier = [x for (hs, x) in hours if hs < s]
                if len(earlier) < SPIKE_HISTORY_HOURS:
                    continue
                base = sum(earlier) / len(earlier)
                if t >= SPIKE_FACTOR * base:
                    cases.append(("user_spike", u, s, t, int(SPIKE_FACTOR * base)))
    out = []
    for case in cases:
        scope, user, window, total = case[:4]
        if scope == "user_spike":
            level, limit = "warn", case[4]
            akey = "|".join([scope, user, window])
            if state["alerted"].get(akey, {}).get("r", 0) >= 1:
                continue
            state["alerted"][akey] = {"r": 1, "w": window[:10]}
            line = {"integration": "claude-enterprise", "feed": "usage", "type": "claude_token_threshold", "id": "th|%s|warn" % akey,
                    "threshold": {"scope": scope, "level": level, "metric": METRIC, "window": window, "limit": limit,
                                  "value": total, "percent_of_limit": round(100.0 * total / max(limit, 1)),
                                  "user_id": user, "email": emails.get(user)}}
            if emails.get(user):
                line["srcuser"] = emails[user]
            out.append(line)
            continue
        warn, crit = THRESHOLDS[(scope, "warn")], THRESHOLDS[(scope, "critical")]
        level = "critical" if crit and total >= crit else "warn" if warn and total >= warn else None
        if not level:
            continue
        akey = "|".join([scope, user or "org", window])
        rank = 2 if level == "critical" else 1
        if state["alerted"].get(akey, {}).get("r", 0) >= rank:
            continue
        state["alerted"][akey] = {"r": rank, "w": window[:10]}
        limit = crit if level == "critical" else warn
        line = {"integration": "claude-enterprise", "feed": "usage", "type": "claude_token_threshold",
                "id": "th|%s|%s" % (akey, level),
                "threshold": {"scope": scope, "level": level, "metric": METRIC, "window": window,
                              "limit": limit, "value": total, "percent_of_limit": round(100.0 * total / limit),
                              "user_id": user, "email": emails.get(user) if user else None}}
        if user and emails.get(user):
            line["srcuser"] = emails[user]
        out.append(line)
    usage_append(out)
    state["total_written"] = state.get("total_written", 0) + len(out)
    return len(out)


def usage_heartbeat(state, status, rows_seen=0, written=0, alerts=0, error=None):
    now = datetime.now(timezone.utc)
    line = {"integration": "claude-enterprise", "feed": "usage", "type": "athena_usage_sync_heartbeat", "usage_sync": {
        "status": status, "interval_seconds": USAGE_INTERVAL, "window_hours": WINDOW_HOURS, "rows_seen": rows_seen,
        "buckets_written": written, "threshold_alerts": alerts, "requests": URUN.get("requests", 0),
        "http_status": URUN.get("http_status"), "duration_ms": int((time.time() - URUN.get("started", time.time())) * 1000),
        "data_refreshed_at": state.get("data_refreshed_at"), "last_success": state.get("last_success"),
        "total_written": state.get("total_written", 0), "error": error, "spend_status": URUN.get("spend"),
        "limits": "|".join("%s.%s=%d" % (s, l, v) for (s, l), v in sorted(THRESHOLDS.items())) + "|spike.factor=%g|spike.min=%d|basis=%s|spend.warn=%g|spend.crit=%g" % (SPIKE_FACTOR, SPIKE_MIN, 0 if BASIS == "total" else 1, SPEND_WARN_PCT, SPEND_CRIT_PCT),
        "at": iso(now)}}
    usage_append([line])


def usage_sync_once():
    state = usage_load_state()
    state.setdefault("buckets", {})
    state.setdefault("alerted", {})
    URUN.clear()
    URUN["started"] = time.time()
    now = datetime.now(timezone.utc)
    try:
        if state.get("last_success"):
            start = (now - timedelta(hours=WINDOW_HOURS)).replace(minute=0, second=0, microsecond=0)
        else:
            log.info("no usage state yet: backfilling %d days", BACKFILL_DAYS)
            start = (now - timedelta(days=BACKFILL_DAYS)).replace(hour=0, minute=0, second=0, microsecond=0)
        start = max(start, datetime(2026, 1, 1, tzinfo=timezone.utc))  # earliest date the API accepts
        end = (now + timedelta(hours=1)).replace(minute=0, second=0, microsecond=0)  # the API requires ending_at with buckets
        rows, refreshed = usage_fetch_all(start, end)
        written, seen = usage_write_buckets(rows, state)
        state["data_refreshed_at"] = refreshed or state.get("data_refreshed_at")
        usage_prune(state, now)
        alerts = usage_evaluate_thresholds(state, now)
        try:
            sp_rows, sp_alerts = usage_write_spend(usage_fetch_spend(), state, now)
            URUN["spend"] = "ok"
            alerts += sp_alerts
        except ApiError as e:   # the usage report must keep working even if spend limits cannot be read
            URUN["spend"] = "error: %s" % str(e)[:80]
            log.warning("spend limits not read: %s", e)
        state["last_success"] = iso(now)
        usage_heartbeat(state, "ok", seen, written, alerts)
        usage_save_state(state)
        log.info("usage sync ok: %d rows seen, %d buckets written, %d threshold alerts, data refreshed %s",
                 seen, written, alerts, state.get("data_refreshed_at"))
        return True
    except ApiError as e:
        usage_heartbeat(state, "error", error=str(e)[:200])
        usage_save_state(state)
        if e.status in (401, 403):
            log.error("authentication/permission problem: %s (the key needs the read:analytics scope)", e)
        else:
            log.error("usage sync failed: %s", e)
        return False




# =====================================================================================================
# SENSITIVE DATA COLLECTOR (PHI, PII, PCI, confidential client data): notification only, nothing is blocked
# Reads the text of chats, uploaded files and artifacts through the Compliance API content endpoints
# (scope read:compliance_user_data), looks for sensitive data, and writes ONE FINDING LINE per item and category to
# claude_content.jsonl. A finding never contains the sensitive value: only the category, the kinds, counts and a
# masked sample (for example "Visa ****1111" or "***-**-6789"). Wazuh rules 101830-101839 rate the lines.
# Detection is pattern based with validation (Luhn for cards, ABA and IBAN checksums, SSN structure) and context
# words for the weaker kinds, so it is a notification aid and not a guarantee that nothing sensitive was sent.
# =====================================================================================================
DLP_ENABLED = os.environ.get("CLAUDE_DLP_ENABLED", "1") != "0"
DLP_INTERVAL = int(os.environ.get("CLAUDE_DLP_INTERVAL", "120"))
DLP_BACKFILL_DAYS = max(0, int(os.environ.get("CLAUDE_DLP_BACKFILL_DAYS", "3")))
DLP_MAX_CHATS = max(1, min(int(os.environ.get("CLAUDE_DLP_MAX_CHATS_PER_RUN", "40")), 100))
DLP_MAX_FILE_BYTES = int(float(os.environ.get("CLAUDE_DLP_MAX_FILE_MB", "5")) * 1048576)
DLP_SCAN_ASSISTANT = os.environ.get("CLAUDE_DLP_SCAN_ASSISTANT", "1") != "0"
DLP_BULK_HITS = int(os.environ.get("CLAUDE_DLP_BULK_HITS", "10"))    # this many high-severity hits in one item = critical
DLP_INTERNAL_DOMAINS = {d.strip().lower() for d in os.environ.get("CLAUDE_DLP_INTERNAL_DOMAINS", "").split(",") if d.strip()}
DLP_OUT_FILE = BASE_DIR / "claude_content.jsonl"
DLP_STATE_FILE = BASE_DIR / "content_state.json"
CONTENT_BASE = "https://api.anthropic.com/v1/compliance/apps"
DLP_SEEN_MAX = 30000
DLP_RUN = {}

import re
import zipfile
import hashlib
import subprocess
import tempfile
from io import BytesIO

# ---- detectors ---------------------------------------------------------------------------------------
_CARD_RE = re.compile(r"(?<![\d-])(?:\d[ -]?){12,18}\d(?![\d-])")
_SSN_RE = re.compile(r"(?<![\d-])(?!000|666|9\d\d)\d{3}([- ])(?!00)\d{2}\1(?!0000)\d{4}(?![\d-])")
_SSN_CTX_RE = re.compile(r"(?i:\b(?:ssn|social security(?: number| no\.?)?|ss ?#)\b)\W{0,4}((?!000|666|9\d\d)\d{3}(?!00)\d{2}(?!0000)\d{4})(?!\d)")
_ITIN_RE = re.compile(r"(?<![\d-])9\d{2}-[7-9]\d-\d{4}(?![\d-])")
_CNIC_RE = re.compile(r"(?<![\d-])\d{5}-\d{7}-\d(?![\d-])")
_ABA_RE = re.compile(r"(?<!\d)\d{9}(?!\d)")
_ABA_CTX = re.compile(r"(?i)\b(?:routing|aba|rtn|ach|wire|transit)\b")
_ACCT_RE = re.compile(r"(?i)\b(?:bank\s+)?(?:account|acct)\s*(?:number|no\.?|num\.?|#)?\s*(?:is|:|=|-)?\s*#?\s*(\d[\d -]{4,20}\d)(?![\d])")
_IBAN_RE = re.compile(r"\b[A-Z]{2}\d{2}(?: ?[A-Z0-9]{4}){2,7}(?: ?[A-Z0-9]{1,3})?\b")
_EMAIL_RE = re.compile(r"(?<![\w.+-])[A-Za-z0-9._%+-]+@([A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,})(?![\w-])")
_PHONE_US_RE = re.compile(r"(?<![\d.])(?:\+?1[ .-]?)?\(?[2-9]\d{2}\)?[ .-]?[2-9]\d{2}[ .-]\d{4}(?![\d])")
_PHONE_INTL_RE = re.compile(r"(?<![\w+])\+(?!1[ -]?\d)[1-9]\d{0,2}[ -]?\(?\d{2,4}\)?[ -]?\d{3,4}[ -]?\d{3,4}(?!\d)")
_ADDR_RE = re.compile(r"\b\d{1,6}\s+(?:[NSEW]\.?\s+)?[A-Z][A-Za-z0-9.'-]*(?:\s+[A-Z][A-Za-z0-9.'-]*){0,3}\s+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Drive|Dr|Lane|Ln|Court|Ct|Way|Place|Pl|Terrace|Highway|Hwy|Parkway|Pkwy)\b\.?")
_DOB_RE = re.compile(r"(?i:\b(?:dob|d\.o\.b\.?|date of birth|birth ?date|born(?: on)?)\b)\W{0,3}(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}-\d{2}-\d{2}|[A-Za-z]{3,9}\.? \d{1,2},? \d{4})")
_GOVID_RE = re.compile(r"(?i:\b(?:passport|driver'?s? licen[sc]e|national id|tax id|ein|tin)\b)[^\n\d]{0,14}?(?i:(?:number|no\.?|#|id))?\W{0,3}((?=[A-Z0-9-]*\d)[A-Z0-9][A-Z0-9-]{5,16})\b")
_NAME_RE = re.compile(r"(?i:\b(?:patient|member|subscriber|insured|beneficiary|customer|employee|applicant)\s+name\s*[:=-])\s*([A-Z][a-z]+(?:\s+[A-Z][a-z'.-]+){1,3})")
_MRN_RE = re.compile(r"(?i:\b(?:mrn|medical record(?: number| no\.?| #)?|chart (?:number|no\.?|#)|patient id)\b)\W{0,3}((?=[A-Z0-9-]*\d)[A-Z0-9][A-Z0-9-]{4,14})\b")
_MEMBER_RE = re.compile(r"(?i:\b(?:(?:member|subscriber|policy|insurance|health plan|medicaid|medicare|beneficiary)\s*(?:id|number|no\.?|#)|group (?:number|no\.?|#)|mbi)\b)\W{0,3}((?=[A-Z0-9-]*\d)[A-Z0-9][A-Z0-9-]{5,19})\b")
_CLAIM_RE = re.compile(r"(?i:\bclaim\s*(?:number|no\.?|#|id)\b)\W{0,3}((?=[A-Z0-9-]*\d)[A-Z0-9][A-Z0-9-]{5,19})\b")
_NPI_RE = re.compile(r"(?i:\bnpi\b)\W{0,4}(\d{10})(?!\d)")
_DEA_RE = re.compile(r"(?i:\bdea\b)\W{0,4}([ABFGHJKLMPRSTUX][A-Z9]\d{7})\b")
_ICD_RE = re.compile(r"(?i:\b(?:icd-?10(?:-cm)?|diagnos[ie]s|dx)\b)[^\n]{0,40}?\b([A-TV-Z]\d{2}(?:\.\d{1,4})?)\b")
_CPT_RE = re.compile(r"(?i:\b(?:cpt|hcpcs)\b)\W{0,4}([A-V]?\d{4,5})\b")
_HEALTH_TERMS = ("diagnosis", "prescription", "medication", "patient", "symptoms", "treatment", "hiv", "cancer", "diabetes", "hypertension",
                 "mental health", "depression", "therapy", "surgery", "lab results", "blood pressure", "insulin", "biopsy", "oncology",
                 "chemotherapy", "psychiatric", "opioid", "medicare", "medicaid", "hipaa", "claim denial", "copay", "deductible",
                 "explanation of benefits", "discharge summary", "prior authorization", "radiology", "pathology", "allergies")
_CONF_MARK_RE = re.compile(r"\b(privileged\s*(?:and|&)\s*confidential|attorney[- ]client|strictly\s+confidential|confidential\s*(?:and|&)\s*proprietary|client[- ]confidential|do\s+not\s+(?:distribute|forward|share)|internal\s+use\s+only|non-disclosure|under\s+(?:an?\s+)?nda)\b", re.I)
_CLIENT_REF_RE = re.compile(r"\b(?:client|customer|matter|contract|invoice|engagement|case)\s*(?:id|no\.?|number|#|ref(?:erence)?)\s*[:#]?\s*([A-Z0-9][A-Z0-9-]{3,19})\b", re.I)
_HEALTH_RE = re.compile(r"\b(" + "|".join(re.escape(t) for t in _HEALTH_TERMS) + r")\b", re.I)

# kind -> (category, severity, label)
KINDS = {
    "card": ("PCI", "high", "payment card number"),
    "ssn": ("PII", "high", "US social security number"),
    "itin": ("PII", "high", "US taxpayer ID (ITIN)"),
    "cnic": ("PII", "high", "Pakistan CNIC"),
    "gov_id": ("PII", "high", "passport, licence or tax ID"),
    "bank_ach": ("PII", "high", "bank routing and account number (ACH)"),
    "iban": ("PII", "high", "IBAN"),
    "bank_routing": ("PII", "medium", "bank routing number"),
    "bank_account": ("PII", "medium", "bank account number"),
    "address": ("PII", "medium", "street address"),
    "dob": ("PII", "medium", "date of birth"),
    "person_name": ("PII", "medium", "labelled person name"),
    "email": ("PII", "low", "external email address"),
    "phone": ("PII", "low", "phone number"),
    "mrn": ("PHI", "high", "medical record number"),
    "member_id": ("PHI", "high", "health insurance member or policy ID"),
    "claim_no": ("PHI", "high", "insurance claim number"),
    "phi_context": ("PHI", "high", "health information with personal identifiers"),
    "icd10": ("PHI", "medium", "ICD-10 diagnosis code"),
    "npi": ("PHI", "medium", "provider NPI"),
    "dea": ("PHI", "medium", "provider DEA number"),
    "cpt": ("PHI", "medium", "CPT or HCPCS procedure code"),
    "conf_marker": ("CONF", "medium", "confidentiality marking (privileged, client confidential, NDA)"),
    "client_ref": ("CONF", "medium", "client, customer, contract or matter reference"),
    "client_context": ("CONF", "high", "confidential material with client references"),
}
_IDENTIFIER_KINDS = {"ssn", "itin", "cnic", "gov_id", "dob", "person_name", "phone", "address", "email", "mrn", "member_id"}
_SEV_RANK = {"low": 1, "medium": 2, "high": 3, "critical": 4}


def _luhn(num):
    total, alt = 0, False
    for ch in reversed(num):
        d = ord(ch) - 48
        if alt:
            d *= 2
            if d > 9:
                d -= 9
        total += d
        alt = not alt
    return total % 10 == 0


def _card_brand(d):
    n = len(d)
    if d[0] == "4" and n in (13, 16, 19):
        return "Visa"
    if n == 16 and (51 <= int(d[:2]) <= 55 or 2221 <= int(d[:4]) <= 2720):
        return "Mastercard"
    if n == 15 and d[:2] in ("34", "37"):
        return "Amex"
    if n in (16, 19) and (d[:4] == "6011" or d[:2] == "65" or 644 <= int(d[:3]) <= 649):
        return "Discover"
    if n in (16, 19) and 3528 <= int(d[:4]) <= 3589:
        return "JCB"
    if n in (14, 16) and (d[:2] in ("36", "38", "39") or 300 <= int(d[:3]) <= 305):
        return "Diners"
    return None


def _aba_ok(d):
    w = (3, 7, 1, 3, 7, 1, 3, 7, 1)
    return sum(int(c) * k for c, k in zip(d, w)) % 10 == 0


def _iban_ok(s):
    s = s.replace(" ", "")
    if not 15 <= len(s) <= 34:
        return False
    r = s[4:] + s[:4]
    return int("".join(str(int(c, 36)) for c in r)) % 97 == 1


def _dea_ok(s):
    d = [int(c) for c in s[2:]]
    return (d[0] + d[2] + d[4] + 2 * (d[1] + d[3] + d[5])) % 10 == d[6]


def _mask_tail(value, keep=4, lead=""):
    v = re.sub(r"\W", "", value)
    return lead + "*" * max(0, len(v) - keep) + v[-keep:] if len(v) > keep else "*" * len(v)


def scan_text(text):
    """Return {kind: {"count": n, "samples": [masked, ...]}} for one piece of text. Never returns raw values."""
    found = {}

    def hit(kind, mask):
        e = found.setdefault(kind, {"count": 0, "samples": []})
        e["count"] += 1
        if len(e["samples"]) < 2 and mask not in e["samples"]:
            e["samples"].append(mask)

    if not text:
        return found
    text = text[:2_000_000]
    for m in _CARD_RE.finditer(text):
        d = re.sub(r"[ -]", "", m.group(0))
        if 13 <= len(d) <= 19 and len(set(d)) > 1 and _luhn(d) and _card_brand(d):
            hit("card", "%s ****%s" % (_card_brand(d), d[-4:]))
    for m in _SSN_RE.finditer(text):
        hit("ssn", "***-**-" + m.group(0)[-4:])
    for m in _SSN_CTX_RE.finditer(text):
        hit("ssn", "***-**-" + m.group(1)[-4:])
    for m in _ITIN_RE.finditer(text):
        hit("itin", "9**-**-" + m.group(0)[-4:])
    for m in _CNIC_RE.finditer(text):
        hit("cnic", "*****-*******-" + m.group(0)[-1:])
    for m in _GOVID_RE.finditer(text):
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}|\d{4}", m.group(1)):   # a date is not an ID
            hit("gov_id", _mask_tail(m.group(1), 2))
    for m in _IBAN_RE.finditer(text):
        if _iban_ok(m.group(0)):
            hit("iban", m.group(0)[:2] + "**" + "*" * 6 + m.group(0).replace(" ", "")[-4:])
    routing = [m for m in _ABA_RE.finditer(text) if _aba_ok(m.group(0)) and _ABA_CTX.search(text[max(0, m.start() - 80):m.end() + 80])]
    accounts = []
    for m in _ACCT_RE.finditer(text):
        d = re.sub(r"[ -]", "", m.group(1))
        if 6 <= len(d) <= 17 and not (13 <= len(d) <= 19 and _luhn(d) and _card_brand(d)):
            accounts.append(d)
    if routing and accounts:
        for d in accounts:
            hit("bank_ach", "acct ****" + d[-4:])
    else:
        for m in routing:
            hit("bank_routing", "routing *****" + m.group(0)[-4:])
        for d in accounts:
            hit("bank_account", "acct ****" + d[-4:])
    for m in _ADDR_RE.finditer(text):
        hit("address", "*** **** " + m.group(0).split()[-1].rstrip("."))   # street name and number are not kept
    for m in _DOB_RE.finditer(text):
        hit("dob", "DOB ******")
    for m in _NAME_RE.finditer(text):
        hit("person_name", m.group(1).split()[0][:1] + "*** " + m.group(1).split()[-1][:1] + "***")
    for m in _EMAIL_RE.finditer(text):
        if m.group(1).lower() not in DLP_INTERNAL_DOMAINS:
            hit("email", "***@" + m.group(1).lower())
    seen_phone = set()
    for rx in (_PHONE_US_RE, _PHONE_INTL_RE):
        for m in rx.finditer(text):
            d = re.sub(r"\D", "", m.group(0))
            if d not in seen_phone and len(set(d)) > 3:
                seen_phone.add(d)
                hit("phone", "***-***-" + d[-4:])
    for m in _MRN_RE.finditer(text):
        hit("mrn", "MRN ****" + m.group(1)[-3:])
    for m in _MEMBER_RE.finditer(text):
        hit("member_id", "ID ****" + m.group(1)[-3:])
    for m in _CLAIM_RE.finditer(text):
        hit("claim_no", "claim ****" + m.group(1)[-3:])
    for m in _NPI_RE.finditer(text):
        if _luhn("80840" + m.group(1)):
            hit("npi", "NPI ******" + m.group(1)[-4:])
    for m in _DEA_RE.finditer(text):
        if _dea_ok(m.group(1)):
            hit("dea", "DEA *******" + m.group(1)[-2:])
    for m in _ICD_RE.finditer(text):
        hit("icd10", m.group(1)[:1] + "**")
    for m in _CPT_RE.finditer(text):
        hit("cpt", "CPT *****")
    terms = {t.lower() for t in _HEALTH_RE.findall(text)}
    if len(terms) >= 3 and _IDENTIFIER_KINDS & set(found):
        hit("phi_context", "%d health terms with identifiers" % len(terms))
    for m in _CONF_MARK_RE.finditer(text):
        hit("conf_marker", "marked " + re.sub(r"\s+", " ", m.group(1).lower())[:40])
    refs = [m for m in _CLIENT_REF_RE.finditer(text) if re.search(r"\d", m.group(1))]
    for m in refs:
        hit("client_ref", "ref ****" + m.group(1)[-3:])
    if refs and "conf_marker" in found:
        hit("client_context", "marked confidential with %d client reference%s" % (len(refs), "" if len(refs) == 1 else "s"))
    return found


def classify(found):
    """Group kinds into one finding per category with a severity. Returns a list of dicts."""
    out = {}
    for kind, v in found.items():
        cat, sev, _ = KINDS[kind]
        o = out.setdefault(cat, {"category": cat, "severity": "low", "kinds": {}, "total": 0, "samples": [], "high_hits": 0})
        o["kinds"][kind] = v["count"]
        o["total"] += v["count"]
        o["samples"] += v["samples"]
        if _SEV_RANK[sev] > _SEV_RANK[o["severity"]]:
            o["severity"] = sev
        if sev == "high":
            o["high_hits"] += v["count"]
    for o in out.values():
        high_kinds = sum(1 for k in o["kinds"] if KINDS[k][1] == "high")
        if o["high_hits"] >= DLP_BULK_HITS or high_kinds >= 3:
            o["severity"] = "critical"
    return list(out.values())


# ---- reading content ---------------------------------------------------------------------------------
def dlp_get(path, params=None, raw=False):
    url = CONTENT_BASE + path + (("?" + urllib.parse.urlencode(params, doseq=True)) if params else "")
    req = urllib.request.Request(url, headers={"x-api-key": API_KEY, "anthropic-version": API_VERSION, "user-agent": "athena-claude-sync/1.0"})
    last = None
    for attempt in range(1, 4):
        DLP_RUN["requests"] = DLP_RUN.get("requests", 0) + 1
        try:
            with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
                if raw:
                    return resp.read(DLP_MAX_FILE_BYTES + 1), resp.headers.get("Content-Type", "")
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", "replace")[:200]
            if e.code == 429:
                time.sleep(min(int(e.headers.get("retry-after", "20") or 20), 60))
                last = ApiError(429, body)
            elif e.code >= 500:
                time.sleep(2 ** attempt)
                last = ApiError(e.code, body)
            else:
                raise ApiError(e.code, body)
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            time.sleep(2 ** attempt)
            last = ApiError(0, str(e))
    raise last


def _strip_xml(xml):
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", xml))


def file_text(data):
    """Best-effort text from stored file bytes. Returns (text or None, reason)."""
    if data[:4] == b"%PDF":
        with tempfile.NamedTemporaryFile(suffix=".pdf") as t:
            t.write(data)
            t.flush()
            try:
                r = subprocess.run(["pdftotext", "-q", "-layout", t.name, "-"], capture_output=True, timeout=30)
                return (r.stdout.decode("utf-8", "replace"), "pdf") if r.returncode == 0 else (None, "pdf unreadable")
            except (OSError, subprocess.TimeoutExpired):
                return None, "pdf unreadable"
    if data[:2] == b"PK":
        try:
            z = zipfile.ZipFile(BytesIO(data))
            parts = []
            for n in z.namelist():
                if n.startswith(("word/", "xl/sharedStrings", "xl/worksheets/", "ppt/slides/")) and n.endswith(".xml"):
                    parts.append(_strip_xml(z.read(n).decode("utf-8", "replace")))
                if sum(len(p) for p in parts) > 2_000_000:
                    break
            return ("\n".join(parts), "office") if parts else (None, "archive")
        except (zipfile.BadZipFile, KeyError):
            return None, "archive"
    if b"\x00" in data[:4096] or data[:4] in (b"\x89PNG", b"\xff\xd8\xff\xe0", b"GIF8"):
        return None, "binary"
    return data.decode("utf-8", "replace"), "text"


def block_text(block):
    t = block.get("type")
    if t == "text":
        return block.get("text") or ""
    if t == "tool_use":
        return json.dumps(block.get("input") or {}, ensure_ascii=False)
    if t == "tool_result":
        c = block.get("content")
        if isinstance(c, list):
            return "\n".join(block_text(x) if isinstance(x, dict) else str(x) for x in c)
        return str(c or "")
    return ""


def dlp_load_state():
    try:
        with open(DLP_STATE_FILE) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"cursor": None, "chats": {}, "files": [], "found": [], "total_written": 0}


def dlp_save_state(st):
    st["files"] = st["files"][-DLP_SEEN_MAX:]
    st["found"] = st["found"][-DLP_SEEN_MAX:]
    if len(st["chats"]) > 20000:
        st["chats"] = dict(sorted(st["chats"].items(), key=lambda kv: kv[1])[-20000:])
    tmp = DLP_STATE_FILE.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(st, f)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, DLP_STATE_FILE)


def dlp_emit(st, chat, source, source_id, role, filename, text, lines):
    found = scan_text(text)
    DLP_RUN["items"] = DLP_RUN.get("items", 0) + 1
    if not found:
        return
    user = chat.get("user") or {}
    for f in classify(found):
        fid = "dlp|%s|%s|%s" % (source_id, f["category"], hashlib.sha1(json.dumps(f["kinds"], sort_keys=True).encode()).hexdigest()[:8])
        if fid in st["found"]:
            continue
        st["found"].append(fid)
        line = {"integration": "claude-enterprise", "feed": "content", "type": "claude_sensitive_data", "id": fid,
                "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "dlp": {"category": f["category"], "severity": f["severity"], "total": f["total"],
                        "kinds": ",".join(sorted(f["kinds"])), "kind_counts": ",".join("%s=%d" % kv for kv in sorted(f["kinds"].items())),
                        "labels": "; ".join(sorted(KINDS[k][2] for k in f["kinds"])), "samples": "; ".join(f["samples"][:4]),
                        "source": source, "source_id": source_id, "role": role, "filename": filename, "chat_id": chat.get("id"),
                        "href": chat.get("href"), "user_id": user.get("id"), "email": user.get("email_address"),
                        "model": chat.get("model"), "chars": len(text)}}
        if user.get("email_address"):
            line["srcuser"] = user["email_address"]
        lines.append(line)


def dlp_scan_chat(st, chat, lines):
    cid = chat["id"]
    params = {"order": "asc"}
    if st["chats"].get(cid):
        params["created_at.gt"] = st["chats"][cid]
    data = dlp_get("/chats/%s/messages" % cid, params)
    newest = st["chats"].get(cid)
    for m in data.get("chat_messages") or []:
        created = m.get("created_at") or ""
        if newest is None or created > newest:
            newest = created
        role = m.get("role")
        if role == "assistant" and not DLP_SCAN_ASSISTANT:
            continue
        text = "\n".join(block_text(b) for b in (m.get("content") or []) if isinstance(b, dict))
        dlp_emit(st, chat, "message", m.get("id"), role, None, text, lines)
        for fobj in (m.get("files") or []):
            fid = fobj.get("id")
            if not fid or fid in st["files"]:
                continue
            st["files"].append(fid)
            if (fobj.get("size_bytes") or 0) > DLP_MAX_FILE_BYTES:
                DLP_RUN["skipped"] = DLP_RUN.get("skipped", 0) + 1
                continue
            try:
                body, _ = dlp_get("/chats/files/%s/content" % fid, raw=True)
            except ApiError as e:
                DLP_RUN["skipped"] = DLP_RUN.get("skipped", 0) + 1
                log.warning("file %s not read: %s", fid, e)
                continue
            if len(body) > DLP_MAX_FILE_BYTES:
                DLP_RUN["skipped"] = DLP_RUN.get("skipped", 0) + 1
                continue
            txt, why = file_text(body)
            if txt is None:
                DLP_RUN["skipped"] = DLP_RUN.get("skipped", 0) + 1
                continue
            DLP_RUN["files"] = DLP_RUN.get("files", 0) + 1
            dlp_emit(st, chat, "file", fid, role, fobj.get("filename"), txt, lines)
        for art in (m.get("artifacts") or []):
            vid = art.get("version_id")
            if not vid or vid in st["files"]:
                continue
            st["files"].append(vid)
            try:
                a = dlp_get("/artifacts/%s/content" % vid)
                dlp_emit(st, chat, "artifact", vid, role, art.get("title"), a.get("content") or "", lines)
            except ApiError:
                DLP_RUN["skipped"] = DLP_RUN.get("skipped", 0) + 1
    if newest:
        st["chats"][cid] = newest


def dlp_append(lines):
    if not lines:
        return
    with open(DLP_OUT_FILE, "a", encoding="utf-8") as f:
        for ln in lines:
            f.write(json.dumps(ln, separators=(",", ":"), ensure_ascii=False) + "\n")
        f.flush()
        os.fsync(f.fileno())


def dlp_sync_once():
    st = dlp_load_state()
    DLP_RUN.clear()
    DLP_RUN["started"] = time.time()
    lines, status, error, chats_done = [], "ok", None, 0
    try:
        params = {"order_by": "updated_at", "limit": DLP_MAX_CHATS}
        if st.get("cursor"):
            params["after_id"] = st["cursor"]
        else:
            params["updated_at.gte"] = (datetime.now(timezone.utc) - timedelta(days=DLP_BACKFILL_DAYS)).strftime("%Y-%m-%dT%H:%M:%SZ")
        page = dlp_get("/chats", params)
        for chat in page.get("data") or []:
            if chat.get("deleted_at"):
                continue
            try:
                dlp_scan_chat(st, chat, lines)
                chats_done += 1
            except ApiError as e:
                DLP_RUN["errors"] = DLP_RUN.get("errors", 0) + 1
                log.warning("chat %s not scanned: %s", chat.get("id"), e)
        if page.get("last_id"):
            st["cursor"] = page["last_id"]
        DLP_RUN["more"] = bool(page.get("has_more"))
    except ApiError as e:
        status, error = "error", str(e)[:200]
        if e.status in (401, 403):
            log.error("content access problem: %s (the key needs the read:compliance_user_data scope)", e)
        else:
            log.error("sensitive data scan failed: %s", e)
    dlp_append(lines)
    st["total_written"] = st.get("total_written", 0) + len(lines)
    st["last_run"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    dlp_append([{"integration": "claude-enterprise", "feed": "content", "type": "athena_dlp_sync_heartbeat", "dlp_sync": {
        "status": status, "interval_seconds": DLP_INTERVAL, "chats_scanned": chats_done, "items_scanned": DLP_RUN.get("items", 0),
        "files_scanned": DLP_RUN.get("files", 0), "items_skipped": DLP_RUN.get("skipped", 0), "findings": len(lines),
        "requests": DLP_RUN.get("requests", 0), "errors": DLP_RUN.get("errors", 0), "more_pending": DLP_RUN.get("more", False),
        "duration_ms": int((time.time() - DLP_RUN["started"]) * 1000), "total_written": st["total_written"], "error": error, "at": st["last_run"]}}])
    dlp_save_state(st)
    log.info("sensitive data scan %s: %d chats, %d items, %d findings, %d skipped", status, chats_done, DLP_RUN.get("items", 0), len(lines), DLP_RUN.get("skipped", 0))
    return status == "ok"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true", help="run a single sync (activities and usage) and exit")
    args = ap.parse_args()

    if not API_KEY:
        log.error("ANTHROPIC_COMPLIANCE_KEY not found (set it with: systemctl edit %s)", KEY_UNIT)
        sys.exit(2)
    BASE_DIR.mkdir(parents=True, exist_ok=True)

    lock = open(LOCK_FILE, "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        log.error("another sync is already running")
        sys.exit(3)

    if args.once:
        ok = sync_once()
        if USAGE_ENABLED:
            ok = usage_sync_once() and ok
        if DLP_ENABLED:
            ok = dlp_sync_once() and ok
        sys.exit(0 if ok else 1)

    log.info("claude sync service started: activities every %ss -> %s%s", INTERVAL, EVENTS_FILE,
             "; usage and spend every %ss -> %s" % (USAGE_INTERVAL, USAGE_OUT_FILE) if USAGE_ENABLED else "; usage collector off")
    log.info("sensitive data scan (PHI, PII, PCI) %s", "every %ss -> %s" % (DLP_INTERVAL, DLP_OUT_FILE) if DLP_ENABLED else "off")
    next_usage = next_dlp = 0.0
    while True:
        try:
            sync_once()
        except Exception:  # never let one bad run kill the service
            log.exception("unexpected error during sync")
        if USAGE_ENABLED and time.time() >= next_usage:
            try:
                usage_sync_once()
            except Exception:
                log.exception("unexpected error during usage sync")
            next_usage = time.time() + USAGE_INTERVAL
        if DLP_ENABLED and time.time() >= next_dlp:
            try:
                dlp_sync_once()
            except Exception:
                log.exception("unexpected error during sensitive data scan")
            next_dlp = time.time() + DLP_INTERVAL
        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
__EOF_claude_sync_py__
ok "$SYNC_DIR/claude_sync.py"

if [ -e "$ENV_DIR/env" ]; then ok "kept your existing $ENV_DIR/env"; else
write_file "$ENV_DIR/env" 0600 root:root <<'__EOF_env__'
# Claude sync tunables. No secrets here: the Compliance key is set with `systemctl edit wazuh-dashboard`.
# After editing this file: systemctl restart claude-sync
CLAUDE_SYNC_INTERVAL=300
CLAUDE_USAGE_INTERVAL=600
CLAUDE_DLP_ENABLED=1
CLAUDE_DLP_INTERVAL=120
CLAUDE_DLP_BACKFILL_DAYS=3
# Comma separated e-mail domains that are NOT reported as external addresses by the content scan
CLAUDE_DLP_INTERNAL_DOMAINS=
# Working window for the off-hours flag: UTC hours "start-end" (end exclusive) and ISO weekdays (1 = Monday)
CLAUDE_WORK_HOURS_UTC=03-15
CLAUDE_WORK_DAYS=1-6
CLAUDE_DORMANT_DAYS=30
# Token alert thresholds (tokens). 0 or unset = that alert is off.
#CLAUDE_TOKEN_USER_DAY_WARN=0
#CLAUDE_TOKEN_USER_DAY_CRIT=0
#CLAUDE_TOKEN_USER_HOUR_WARN=0
#CLAUDE_TOKEN_USER_HOUR_CRIT=0
#CLAUDE_TOKEN_ORG_DAY_WARN=0
#CLAUDE_TOKEN_ORG_DAY_CRIT=0
#CLAUDE_TOKEN_SPIKE_FACTOR=0
#CLAUDE_TOKEN_SPIKE_MIN=1000000
CLAUDE_TOKEN_BASIS=fresh
CLAUDE_SPEND_WARN_PCT=80
CLAUDE_SPEND_CRIT_PCT=100
__EOF_env__
ok "$ENV_DIR/env (tunables, no secrets)"; fi

write_file "$UNIT" 0644 root:root <<'__EOF_unit__'
[Unit]
Description=Claude Enterprise sync (activities, token usage and spend, content scan -> JSONL for Wazuh)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/claude
# Tunables (no secrets): /etc/claude-sync/env. The Compliance key (ANTHROPIC_COMPLIANCE_KEY) is read by the sync from the
# Environment= of the wazuh-dashboard unit: edit it with `systemctl edit wazuh-dashboard`, then `systemctl restart claude-sync`.
EnvironmentFile=-/etc/claude-sync/env
ExecStart=/usr/bin/python3 -u /opt/claude/claude_sync.py
Restart=on-failure
RestartSec=60
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
__EOF_unit__
SETKEY=$(mktemp)
cat > "$SETKEY" <<'__EOF_set_key__'
#!/usr/bin/env python3
"""Put ANTHROPIC_COMPLIANCE_KEY into a systemd drop-in (the equivalent of `systemctl edit <unit>`), idempotently.
usage: set_key.py DROPIN_FILE      (the key is read from the environment variable NEW_KEY, never from argv)"""
import os, re, shutil, stat, sys, time

path, key = sys.argv[1], os.environ["NEW_KEY"]
esc = key.replace("\\", "\\\\").replace('"', '\\"').replace("%", "%%")
line = 'Environment="ANTHROPIC_COMPLIANCE_KEY=%s"\n' % esc
old = open(path).read() if os.path.exists(path) else ""
kept = [l for l in old.splitlines(True) if not re.match(r'\s*Environment=\s*"?ANTHROPIC_COMPLIANCE_KEY=', l)]
if not any(l.strip() == "[Service]" for l in kept):
    kept = ["[Service]\n"] + kept
i = next(n for n, l in enumerate(kept) if l.strip() == "[Service]")
kept.insert(i + 1, line)
if os.path.exists(path):
    b = "%s.bak-%s" % (path, time.strftime("%Y%m%d-%H%M%S"))
    shutil.copy2(path, b); os.chmod(b, 0o600)
tmp = path + ".tmp"
with open(tmp, "w") as f:
    f.write("".join(kept))
os.chmod(tmp, 0o600)
os.replace(tmp, path)
__EOF_set_key__
if systemctl cat wazuh-dashboard >/dev/null 2>&1; then
  KEY_TARGET="$WD_OVERRIDE"; KEY_UNIT=wazuh-dashboard
  install -d -m 0755 -o root -g root "$(dirname "$WD_OVERRIDE")"
else
  KEY_TARGET="$DROPIN_DIR/10-credentials.conf"; KEY_UNIT=claude-sync
  install -d -m 0750 -o root -g root "$DROPIN_DIR"
  warn "no wazuh-dashboard unit on this host: storing the key in the claude-sync drop-in instead"
fi
NEW_KEY="$CLAUDE_COMPLIANCE_KEY" python3 "$SETKEY" "$KEY_TARGET"; rm -f "$SETKEY"
chmod 0600 "$KEY_TARGET"
# an older install kept the key in the env file: remove it so there is exactly one copy
if [ -f "$ENV_DIR/env" ] && grep -q '^ANTHROPIC_COMPLIANCE_KEY=' "$ENV_DIR/env"; then sed -i '/^ANTHROPIC_COMPLIANCE_KEY=/d' "$ENV_DIR/env"; ok "removed the old key line from $ENV_DIR/env"; fi
if [ "$KEY_UNIT" = wazuh-dashboard ]; then rm -rf "$DROPIN_DIR"; fi
systemctl daemon-reload
if systemctl show "$KEY_UNIT" --property=Environment --value | grep -q 'ANTHROPIC_COMPLIANCE_KEY='; then
  ok "Compliance key stored in $KEY_TARGET (mode 0600; change it with: systemctl edit $KEY_UNIT)"
else die "the key was not picked up by systemd from $KEY_TARGET"; fi
if [ "$KEY_UNIT" = wazuh-dashboard ]; then ok "no restart of wazuh-dashboard is needed: the sync reads the key from the unit's configuration"; fi

write_file /etc/logrotate.d/claude-sync 0644 root:root <<'__EOF_logrotate__'
# Claude Enterprise sync output. Real data lives in wazuh-alerts-*; these files are only a short-term buffer.
/opt/claude/claude_activities.jsonl /opt/claude/claude_usage.jsonl /opt/claude/claude_content.jsonl {
    daily
    rotate 7
    missingok
    notifempty
    compress
    delaycompress
    dateext
    create 0640 root wazuh
}
__EOF_logrotate__
ok "/etc/logrotate.d/claude-sync"

# ------------------------------------------------------------------------------------------------ wazuh
step "Installing the Wazuh rules and log sources"
RULES_BAK=$(mktemp -d)
for f in $RULE_FILES; do [ -e "$RULES_DIR/$f" ] && cp -p "$RULES_DIR/$f" "$RULES_BAK/$f"; done
cp -p "$OSSEC_CONF" "$RULES_BAK/ossec.conf"
write_file "$RULES_DIR/claude_rules.xml" 0660 root:wazuh <<'__EOF_rules_main__'
<!--
  Claude Enterprise (Compliance API Activity Feed) - Wazuh ruleset  [DRAFT, NOT INSTALLED]
  =========================================================================================
  Pipeline:
    claude_sync.py (every 5 min)
      -> /opt/claude/claude_activities.jsonl      (one JSON event per line, "integration":"claude-enterprise" added)
      -> <localfile><log_format>json</log_format>  (manager ossec.conf, see claude_localfile_snippet.xml)
      -> built-in JSON decoder                     (nested keys become actor.type, actor.user_id, ...)
      -> THESE RULES
      -> alerts.json -> Filebeat -> wazuh-alerts-4.x-*

  Deploy (after review): /var/ossec/etc/rules/claude_rules.xml, chown wazuh:wazuh, chmod 660,
                         then systemctl restart wazuh-manager. Test with /var/ossec/bin/wazuh-logtest.

  ID range: 101700-101799 (checked: unused in /var/ossec/etc/rules and /var/ossec/ruleset/rules).

  Evaluation-order note (verified with wazuh-logtest -v): sibling rules under one parent are tried by LEVEL,
  highest first (level-0 suppression rules are tried before everything), and the FIRST match fires. Rules of equal
  level are tried in file order. So a specific rule must have a level >= the general rule it should beat
  (101702 is level 10 so it wins over the generic failed-call rule 101704 at level 9).
  The catch-all (101799) is level 3 and must stay LAST in the file among the level-3 rules.

  Evidence status of each rule (events seen in the real feed on 2026-10-24..26):
    OBSERVED  : compliance_api_accessed, api_key_created, org_analytics_api_capability_updated,
                org_compliance_api_settings_updated, claude_chat_created, claude_chat_viewed,
                claude_file_uploaded, claude_file_viewed, claude_chat_access_failed
    PROVISIONAL (event name exists in Anthropic's list, never seen yet, thresholds are guesses):
                login events (sso_/magic_link_/social_), upload-burst and failed-access frequency rules

  Sync enrichment (claude_sync.py): every event also carries "srcip" (copy of actor.ip_address, gives GeoLocation)
  and "srcuser" (email, when the actor has one). The sync writes a type "athena_sync_heartbeat" line every 5 minutes
  (rules 101750/101751); the plugin must exclude groups claude_heartbeat and claude_selfnoise from activity views.
  Rules 101743, 101760-101772 cover event types that exist in Anthropic's list but were NOT observed yet.

  Levels: 0 = suppressed, 3 = informational (indexed), 5-6 = notice, 7-9 = warning, 10-12 = high.
  Notification threshold suggestion: rule.level >= 10.

  KNOWN LIMITS
    * "New IP for this user" cannot be expressed as a native Wazuh rule (no memory of past values).
      Proposed: the sync service adds a flag "new_ip_for_user":true to such events; a rule then matches that flag.
    * Own-poller suppression (101701) matches the key id and user agent of OUR sync. If the key is replaced,
      update the apikey_ id in 101701/101702.
    * Array fields (e.g. scopes) are decoded as a single string like "['read:x', 'write:y']"; rules use regex on it.
    * Activities carry no message text and no file names, so no rule can use them.
-->
<group name="claude,claude_enterprise,">

  <!-- ============================================================ -->
  <!-- BASE: 101700                                                 -->
  <!-- ============================================================ -->
  <rule id="101700" level="0">
    <decoded_as>json</decoded_as>
    <field name="integration">^claude-enterprise$</field>
    <field name="feed">^activity$</field>
    <description>Claude Enterprise: Compliance API activity event.</description>
  </rule>

  <!-- ============================================================ -->
  <!-- COMPLIANCE API ACCESS: 101701-101704                         -->
  <!-- Our own successful polls are suppressed (about 288/day).     -->
  <!-- ============================================================ -->
  <rule id="101701" level="0">
    <if_sid>101700</if_sid>
    <field name="type">^compliance_api_accessed$</field>
    <field name="actor.api_key_id">^apikey_01DZ851g66d6UMWS264ispAe$</field>
    <field name="actor.user_agent">^athena-claude-sync/</field>
    <field name="status_code">^200$</field>
    <description>Claude Enterprise: successful poll by the Athena sync service (suppressed).</description>
    <group>claude_selfnoise,</group>
  </rule>

  <rule id="101702" level="10">
    <if_sid>101700</if_sid>
    <field name="type">^compliance_api_accessed$</field>
    <field name="actor.api_key_id">^apikey_01DZ851g66d6UMWS264ispAe$</field>
    <field name="actor.user_agent">^athena-claude-sync/</field>
    <field name="status_code" negate="yes">^200$</field>
    <description>Claude Enterprise: Athena sync call FAILED (HTTP $(status_code)) - ingestion may be stalled.</description>
    <group>claude_health,claude_compliance_access,</group>
  </rule>

  <rule id="101704" level="9">
    <if_sid>101700</if_sid>
    <field name="type">^compliance_api_accessed$</field>
    <field name="status_code" negate="yes">^200$</field>
    <description>Claude Enterprise: failed Compliance API call (HTTP $(status_code)) by key $(actor.api_key_id) from $(actor.ip_address).</description>
    <group>claude_compliance_access,authentication_failed,</group>
  </rule>

  <rule id="101703" level="7">
    <if_sid>101700</if_sid>
    <field name="type">^compliance_api_accessed$</field>
    <description>Claude Enterprise: Compliance API queried by key $(actor.api_key_id) from $(actor.ip_address) ($(actor.user_agent)) - not the Athena sync client.</description>
    <group>claude_compliance_access,</group>
  </rule>

  <!-- ============================================================ -->
  <!-- ADMIN / SETTINGS: 101710-101715                              -->
  <!-- ============================================================ -->
  <rule id="101710" level="12">
    <if_sid>101700</if_sid>
    <field name="type">^org_compliance_api_settings_updated$</field>
    <field name="compliance_api_enabled">^false$</field>
    <description>Claude Enterprise: Compliance API was TURNED OFF by $(actor.email_address) - audit recording stops and the gap cannot be recovered.</description>
    <group>claude_admin,claude_compliance_settings,</group>
  </rule>

  <rule id="101711" level="12">
    <if_sid>101700</if_sid>
    <field name="type">^org_compliance_api_settings_updated$</field>
    <field name="compliance_api_logging_enabled">^false$</field>
    <description>Claude Enterprise: Compliance API activity logging was TURNED OFF by $(actor.email_address).</description>
    <group>claude_admin,claude_compliance_settings,</group>
  </rule>

  <rule id="101712" level="6">
    <if_sid>101700</if_sid>
    <field name="type">^org_compliance_api_settings_updated$</field>
    <description>Claude Enterprise: Compliance API settings changed by $(actor.email_address) (enabled=$(compliance_api_enabled), logging=$(compliance_api_logging_enabled)).</description>
    <group>claude_admin,claude_compliance_settings,</group>
  </rule>

  <rule id="101713" level="5">
    <if_sid>101700</if_sid>
    <field name="type">^org_analytics_api_capability_updated$</field>
    <description>Claude Enterprise: Analytics API capability changed by $(actor.email_address) ($(previous_value) to $(current_value)).</description>
    <group>claude_admin,</group>
  </rule>

  <rule id="101714" level="10">
    <if_sid>101700</if_sid>
    <field name="type">^api_key_created$</field>
    <field name="scopes" type="pcre2">(delete|write):</field>
    <description>Claude Enterprise: API key $(api_key_id) created by $(actor.email_address) WITH delete/write scopes.</description>
    <group>claude_admin,claude_api_key,</group>
  </rule>

  <rule id="101715" level="8">
    <if_sid>101700</if_sid>
    <field name="type">^api_key_created$</field>
    <description>Claude Enterprise: API key $(api_key_id) created by $(actor.email_address) (read-only scopes).</description>
    <group>claude_admin,claude_api_key,</group>
  </rule>

  <!-- ============================================================ -->
  <!-- USER ACTIVITY (chat / file): 101720-101724                   -->
  <!-- ============================================================ -->
  <rule id="101720" level="3">
    <if_sid>101700</if_sid>
    <field name="type">^claude_chat_created$</field>
    <description>Claude Enterprise: chat created by $(actor.email_address) from $(actor.ip_address).</description>
    <group>claude_chat,claude_user_activity,</group>
  </rule>

  <rule id="101722" level="3">
    <if_sid>101700</if_sid>
    <field name="type">^claude_file_uploaded$</field>
    <description>Claude Enterprise: file uploaded by $(actor.email_address) from $(actor.ip_address) (file $(claude_file_id)).</description>
    <group>claude_file,claude_upload,claude_user_activity,</group>
  </rule>

  <rule id="101724" level="6">
    <if_sid>101700</if_sid>
    <field name="type">^claude_chat_access_failed$</field>
    <description>Claude Enterprise: failed attempt to access chat $(claude_chat_id) by $(actor.email_address) from $(actor.ip_address).</description>
    <group>claude_chat,claude_access_failed,claude_user_activity,</group>
  </rule>

  <!-- "viewed" events fire on every app load (noisy): level 3 but grouped so the UI can hide them. -->
  <rule id="101721" level="3">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^claude_(chat|file|project)_viewed$</field>
    <description>Claude Enterprise: content loaded ($(type)) by $(actor.email_address).</description>
    <group>claude_viewed,claude_user_activity,</group>
  </rule>

  <!-- ============================================================ -->
  <!-- LOGIN EVENTS: 101740-101743   [PROVISIONAL - never observed] -->
  <!-- ============================================================ -->
  <rule id="101740" level="5">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^(sso_login_failed|magic_link_login_failed|anonymous_mobile_login_attempted)$</field>
    <description>Claude Enterprise: login problem ($(type)) from $(actor.ip_address).</description>
    <group>claude_auth,authentication_failed,</group>
  </rule>

  <rule id="101741" level="3">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^(sso_login_succeeded|magic_link_login_succeeded|social_login_succeeded)$</field>
    <description>Claude Enterprise: user login succeeded ($(type)) from $(actor.ip_address).</description>
    <group>claude_auth,authentication_success,</group>
  </rule>

  <!-- ============================================================ -->
  <!-- CORRELATION (frequency) [PROVISIONAL thresholds]             -->
  <!-- ============================================================ -->
  <rule id="101730" level="10" frequency="10" timeframe="120">
    <if_matched_group>claude_upload</if_matched_group>
    <same_field>actor.user_id</same_field>
    <description>Claude Enterprise: upload burst - 10 or more file uploads in 2 minutes by $(actor.email_address).</description>
    <group>claude_correlation,claude_upload_burst,</group>
  </rule>

  <rule id="101731" level="9" frequency="5" timeframe="300">
    <if_matched_group>claude_access_failed</if_matched_group>
    <same_field>actor.user_id</same_field>
    <description>Claude Enterprise: 5 or more failed chat-access attempts in 5 minutes by $(actor.email_address).</description>
    <group>claude_correlation,</group>
  </rule>

  <rule id="101742" level="10" frequency="5" timeframe="300">
    <if_matched_group>authentication_failed</if_matched_group>
    <same_field>actor.ip_address</same_field>
    <description>Claude Enterprise: 5 or more failed logins or API authentications in 5 minutes from $(actor.ip_address).</description>
    <group>claude_correlation,claude_auth,authentication_failures,</group>
  </rule>

  <!-- ============================================================ -->
  <!-- SYNC HEARTBEAT (Integration Health): 101750-101751           -->
  <!-- One line per 5 min written by claude_sync.py (not a Claude event). -->
  <!-- ============================================================ -->
  <rule id="101751" level="8">
    <if_sid>101700</if_sid>
    <field name="type">^athena_sync_heartbeat$</field>
    <field name="sync.status">^error$</field>
    <description>Claude Enterprise sync ERROR: $(sync.error)</description>
    <group>claude_health,claude_heartbeat,claude_sync_error,</group>
  </rule>

  <rule id="101750" level="3">
    <if_sid>101700</if_sid>
    <field name="type">^athena_sync_heartbeat$</field>
    <description>Claude Enterprise sync heartbeat: status=$(sync.status), new events=$(sync.new_events), rate limit remaining=$(sync.rate_limit_remaining).</description>
    <group>claude_health,claude_heartbeat,</group>
  </rule>

  <!-- ============================================================ -->
  <!-- EXTENDED EVENT TYPES [PROVISIONAL - names exist in Anthropic's -->
  <!-- activity list but have NOT been observed yet]                -->
  <!-- Groups feed the Overview buckets: claude_project, claude_admin,-->
  <!-- claude_rbac, claude_auth, claude_chat, claude_file.          -->
  <!-- ============================================================ -->
  <rule id="101766" level="8">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^(rbac_|role_assignment_)</field>
    <description>Claude Enterprise: role/permission change ($(type)) by $(actor.email_address).</description>
    <group>claude_admin,claude_rbac,</group>
  </rule>

  <rule id="101769" level="8">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^(org_data_export_(started|completed|accessed)|org_members_exported)$</field>
    <description>Claude Enterprise: organization data export ($(type)) by $(actor.email_address).</description>
    <group>claude_admin,claude_data_export,</group>
  </rule>

  <rule id="101770" level="6">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^(claude_organization_settings_updated|org_member_invites_(enabled|disabled)|org_invite_link_(generated|regenerated|disabled))$</field>
    <description>Claude Enterprise: organization setting changed ($(type)) by $(actor.email_address).</description>
    <group>claude_admin,</group>
  </rule>

  <rule id="101767" level="6">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^group_member_(added|removed)$</field>
    <description>Claude Enterprise: group membership changed ($(type)) by $(actor.email_address).</description>
    <group>claude_admin,</group>
  </rule>

  <rule id="101768" level="5">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^scim_user_(created|updated|deleted)$</field>
    <description>Claude Enterprise: directory sync user change ($(type)).</description>
    <group>claude_admin,claude_scim,</group>
  </rule>

  <rule id="101772" level="3">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^org_user_invite_(sent|accepted|rejected|deleted|re_sent)$</field>
    <description>Claude Enterprise: user invitation event ($(type)) by $(actor.email_address).</description>
    <group>claude_admin,claude_invites,</group>
  </rule>

  <rule id="101771" level="6">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^(session_revoked|step_up_authentication_failed)$</field>
    <description>Claude Enterprise: session or step-up authentication event ($(type)) from $(actor.ip_address).</description>
    <group>claude_auth,</group>
  </rule>

  <rule id="101743" level="3">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^(sso_login_initiated|magic_link_login_initiated|sso_second_factor_magic_link|step_up_authentication_succeeded)$</field>
    <description>Claude Enterprise: authentication step ($(type)) from $(actor.ip_address).</description>
    <group>claude_auth,</group>
  </rule>

  <rule id="101761" level="6">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^claude_project_(deleted|sharing_updated|reported)$</field>
    <description>Claude Enterprise: project ($(type)) by $(actor.email_address).</description>
    <group>claude_project,claude_user_activity,</group>
  </rule>

  <rule id="101762" level="5">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^claude_chat_(deleted|deletion_failed)$</field>
    <description>Claude Enterprise: chat deletion event ($(type)) by $(actor.email_address).</description>
    <group>claude_chat,claude_user_activity,</group>
  </rule>

  <rule id="101764" level="6">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^claude_file_(deleted|exported|access_failed)$</field>
    <description>Claude Enterprise: file event ($(type)) file $(claude_file_id) by $(actor.email_address).</description>
    <group>claude_file,claude_user_activity,</group>
  </rule>

  <rule id="101760" level="3">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^claude_project_</field>
    <description>Claude Enterprise: project activity ($(type)) by $(actor.email_address).</description>
    <group>claude_project,claude_user_activity,</group>
  </rule>

  <rule id="101763" level="3">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^claude_chat_</field>
    <description>Claude Enterprise: chat activity ($(type)) by $(actor.email_address).</description>
    <group>claude_chat,claude_user_activity,</group>
  </rule>

  <!-- ============================================================ -->
  <!-- CATCH-ALL: 101799 (keep LAST) - new event types still show up -->
  <!-- ============================================================ -->
  <rule id="101799" level="3">
    <if_sid>101700</if_sid>
    <description>Claude Enterprise: other activity ($(type)) by $(actor.email_address).</description>
    <group>claude_other,</group>
  </rule>

</group>
__EOF_rules_main__
write_file "$RULES_DIR/claude_security_rules.xml" 0660 root:wazuh <<'__EOF_rules_security__'
<!--
  Claude Enterprise security use cases - Wazuh ruleset, ids 101800-101829
  =======================================================================
  These rules sit on top of the activity rules (101700-101799) and use three kinds of signal:
    1. Flags added by claude_sync.py to each activity line (it remembers every actor between runs):
         new_ip_for_actor : true    the actor (user or API key) used an IP never seen before for them
         off_hours        : true    a user acted outside the working window (CLAUDE_WORK_HOURS_UTC / CLAUDE_WORK_DAYS)
         dormant_days     : N       the user came back after N days (>= CLAUDE_DORMANT_DAYS) without any activity
    2. Fields already in the feed (user agent, event type, actor type).
    3. Wazuh correlation (frequency over a time window, same actor).
  A higher-level sibling is tried first, so each specific rule here is higher than the plain rule it refines
  and carries the same groups, so existing burst/failure counters keep counting these events.
-->
<group name="claude_enterprise,claude_security,">

  <!-- ============================================================ -->
  <!-- DATA LEAVING THE ORGANIZATION (proxy signals; the feed has no content) -->
  <!-- ============================================================ -->
  <rule id="101801" level="10">
    <if_sid>101700</if_sid>
    <field name="type">^claude_file_uploaded$</field>
    <field name="new_ip_for_actor">^true$</field>
    <description>Claude security: file uploaded by $(actor.email_address) from a NEW IP $(actor.ip_address)</description>
    <group>claude_file,claude_upload,claude_user_activity,claude_new_ip,claude_exfil,</group>
  </rule>

  <rule id="101802" level="9">
    <if_sid>101700</if_sid>
    <field name="type">^claude_file_uploaded$</field>
    <field name="off_hours">^true$</field>
    <description>Claude security: file uploaded by $(actor.email_address) outside working hours</description>
    <group>claude_file,claude_upload,claude_user_activity,claude_off_hours,claude_exfil,</group>
  </rule>

  <rule id="101803" level="9" frequency="20" timeframe="300">
    <if_matched_group>claude_viewed</if_matched_group>
    <same_field>actor.user_id</same_field>
    <description>Claude security: bulk reading - 20 or more chats/files/projects opened in 5 minutes by $(actor.email_address)</description>
    <group>claude_correlation,claude_exfil,claude_bulk_read,</group>
  </rule>

  <rule id="101804" level="10" frequency="5" timeframe="300">
    <if_matched_sid>101762</if_matched_sid>
    <same_field>actor.user_id</same_field>
    <description>Claude security: bulk deletion - 5 or more chat deletions in 5 minutes by $(actor.email_address) (evidence removal)</description>
    <group>claude_correlation,claude_bulk_delete,</group>
  </rule>

  <rule id="101805" level="10" frequency="2" timeframe="600">
    <if_sid>101762</if_sid>
    <if_matched_group>claude_upload</if_matched_group>
    <same_field>actor.user_id</same_field>
    <description>Claude security: deletion right after uploads - $(actor.email_address) deleted a chat within 10 minutes of uploading files</description>
    <group>claude_correlation,claude_exfil,claude_cover_tracks,</group>
  </rule>

  <rule id="101806" level="9">
    <if_sid>101700</if_sid>
    <field name="type" type="pcre2">^claude_file_exported$</field>
    <field name="off_hours">^true$</field>
    <description>Claude security: file exported by $(actor.email_address) outside working hours</description>
    <group>claude_file,claude_user_activity,claude_off_hours,claude_exfil,</group>
  </rule>

  <!-- ============================================================ -->
  <!-- ACCOUNT TAKEOVER AND IDENTITY                                -->
  <!-- ============================================================ -->
  <rule id="101810" level="10">
    <if_sid>101700</if_sid>
    <field name="new_ip_for_actor">^true$</field>
    <field name="actor.type" type="pcre2">^(api_actor|admin_api_key_actor)$</field>
    <description>Claude security: API key $(actor.api_key_id) used from a NEW IP $(actor.ip_address) (possible key theft)</description>
    <group>claude_new_ip,claude_api_key,claude_identity,</group>
  </rule>

  <rule id="101811" level="10">
    <if_sid>101700</if_sid>
    <field name="new_ip_for_actor">^true$</field>
    <field name="type" type="pcre2">^(api_key_|rbac_|role_assignment_|scim_|group_member_|org_data_export|org_members_exported|org_compliance_api|org_analytics_api|session_revoked)</field>
    <description>Claude security: sensitive admin action ($(type)) by $(actor.email_address) from a NEW IP $(actor.ip_address)</description>
    <group>claude_admin,claude_new_ip,claude_identity,</group>
  </rule>

  <rule id="101812" level="8">
    <if_sid>101700</if_sid>
    <field name="dormant_days" type="pcre2">^\d+$</field>
    <description>Claude security: dormant account active again - $(actor.email_address) returned after $(dormant_days) days without activity</description>
    <group>claude_identity,claude_dormant,</group>
  </rule>

  <rule id="101813" level="8">
    <if_sid>101700</if_sid>
    <field name="actor.type">^user_actor$</field>
    <field name="actor.user_agent" type="pcre2">(?i)^(curl|python|wget|go-http|axios|node-fetch|postmanruntime|okhttp|java/|libwww|httpie)</field>
    <description>Claude security: scripted client ($(actor.user_agent)) acting as user $(actor.email_address)</description>
    <group>claude_identity,claude_scripted_client,</group>
  </rule>

  <rule id="101814" level="9" frequency="3" timeframe="600">
    <if_matched_group>claude_user_activity</if_matched_group>
    <same_field>actor.user_id</same_field>
    <different_srcip />
    <description>Claude security: $(actor.email_address) active from 3 different IPs within 10 minutes (shared or hijacked account)</description>
    <group>claude_correlation,claude_identity,</group>
  </rule>

  <rule id="101815" level="6">
    <if_sid>101700</if_sid>
    <field name="new_ip_for_actor">^true$</field>
    <field name="actor.type">^user_actor$</field>
    <description>Claude security: $(actor.email_address) used a NEW IP $(actor.ip_address)</description>
    <group>claude_new_ip,claude_identity,</group>
  </rule>

  <!-- ============================================================ -->
  <!-- ADMIN AND MONITORING INTEGRITY                               -->
  <!-- ============================================================ -->
  <rule id="101820" level="10" frequency="3" timeframe="600">
    <if_matched_group>claude_admin</if_matched_group>
    <same_field>actor.user_id</same_field>
    <description>Claude security: admin change burst - 3 or more admin changes in 10 minutes by $(actor.email_address)</description>
    <group>claude_correlation,claude_admin,</group>
  </rule>

  <rule id="101821" level="7">
    <if_sid>101700</if_sid>
    <field name="off_hours">^true$</field>
    <field name="type" type="pcre2">^(claude_chat_created|claude_chat_deleted|claude_file_uploaded)$</field>
    <description>Claude security: $(actor.email_address) active outside working hours ($(type))</description>
    <group>claude_off_hours,claude_identity,</group>
  </rule>

</group>
__EOF_rules_security__
write_file "$RULES_DIR/claude_usage_rules.xml" 0660 root:wazuh <<'__EOF_rules_usage__'
<!--
  Claude Enterprise token usage (Analytics API per-user usage report) - Wazuh ruleset, ids 101780-101789
  Pipeline: claude_usage_sync.py (every 10 min) -> /opt/claude/claude_usage.jsonl -> localfile json -> built-in JSON decoder
            -> these rules -> alerts.json -> Filebeat -> wazuh-alerts-4.x-*
  Lines carry "integration":"claude-enterprise" and "feed":"usage" (activity lines are feed "activity", content scan lines are feed "content").
  Wazuh cannot add numbers across events, so the sync service sums the buckets itself and writes one
  claude_token_threshold line when a limit is first reached; the rules below only rate that line.
  Limits live in /etc/claude-sync/env (CLAUDE_TOKEN_*). The usage report is refreshed by Anthropic about every 4 hours.
-->
<group name="claude_enterprise,claude_usage,">

  <rule id="101780" level="0">
    <decoded_as>json</decoded_as>
    <field name="integration">^claude-enterprise$</field>
    <field name="feed">^usage$</field>
    <description>Claude Enterprise usage feed</description>
  </rule>

  <!-- monthly spend limit (claude_usage_sync.py reads the Spend Limits API): amounts are in cents; listed before the
       token rules so they win at equal level -->
  <rule id="101789" level="10">
    <if_sid>101780</if_sid>
    <field name="type">^claude_token_threshold$</field>
    <field name="threshold.scope">^user_spend$</field>
    <field name="threshold.level">^critical$</field>
    <description>Claude spend CRITICAL: $(threshold.email) used $(threshold.percent_of_limit)% of their monthly spend limit ($(threshold.value) of the cap, in cents)</description>
    <group>claude_token_alert,claude_spend_alert,</group>
  </rule>

  <rule id="101788" level="7">
    <if_sid>101780</if_sid>
    <field name="type">^claude_token_threshold$</field>
    <field name="threshold.scope">^user_spend$</field>
    <field name="threshold.level">^warn$</field>
    <description>Claude spend warning: $(threshold.email) used $(threshold.percent_of_limit)% of their monthly spend limit ($(threshold.value) of the cap, in cents)</description>
    <group>claude_token_alert,claude_spend_alert,</group>
  </rule>

  <rule id="101787" level="3">
    <if_sid>101780</if_sid>
    <field name="type">^claude_spend$</field>
    <description>Claude spend: $(spend.email) at $(spend.percent)% of the monthly spend limit</description>
    <group>claude_usage_spend,</group>
  </rule>

  <rule id="101786" level="10">
    <if_sid>101780</if_sid>
    <field name="type">^claude_token_threshold$</field>
    <field name="threshold.level">^critical$</field>
    <description>Claude token usage CRITICAL: $(threshold.scope) $(threshold.email) reached $(threshold.value) tokens (limit $(threshold.limit), window $(threshold.window))</description>
    <group>claude_token_alert,</group>
  </rule>

  <rule id="101785" level="7">
    <if_sid>101780</if_sid>
    <field name="type">^claude_token_threshold$</field>
    <field name="threshold.level">^warn$</field>
    <description>Claude token usage warning: $(threshold.scope) $(threshold.email) reached $(threshold.value) tokens (limit $(threshold.limit), window $(threshold.window))</description>
    <group>claude_token_alert,</group>
  </rule>

  <rule id="101783" level="8">
    <if_sid>101780</if_sid>
    <field name="type">^athena_usage_sync_heartbeat$</field>
    <field name="usage_sync.status">^error$</field>
    <description>Claude usage sync ERROR: $(usage_sync.error)</description>
    <group>claude_usage_heartbeat,claude_usage_error,</group>
  </rule>

  <rule id="101782" level="3">
    <if_sid>101780</if_sid>
    <field name="type">^athena_usage_sync_heartbeat$</field>
    <description>Claude usage sync heartbeat: status=$(usage_sync.status), buckets written=$(usage_sync.buckets_written)</description>
    <group>claude_usage_heartbeat,</group>
  </rule>

  <rule id="101781" level="3">
    <if_sid>101780</if_sid>
    <field name="type">^claude_usage$</field>
    <description>Claude token usage: $(usage.email) $(usage.total_tokens) tokens ($(usage.product), $(usage.model), $(usage.starting_at))</description>
    <group>claude_usage_bucket,</group>
  </rule>

</group>
__EOF_rules_usage__
write_file "$RULES_DIR/claude_dlp_rules.xml" 0660 root:wazuh <<'__EOF_rules_dlp__'
<!--
  Claude Enterprise sensitive data (PHI, PII, PCI) - Wazuh ruleset, ids 101830-101839. NOTIFICATION ONLY, nothing is blocked.
  Lines carry "integration":"claude-enterprise" and "feed":"content".
  Pipeline: claude_sync.py (sensitive data scan, every 2 min) -> /opt/claude/claude_content.jsonl -> localfile json
            -> built-in JSON decoder -> these rules -> alerts.json -> Filebeat -> wazuh-alerts-4.x-*
  A finding line never holds the sensitive value, only dlp.category (PCI|PII|PHI), dlp.severity, the kinds found,
  counts and a masked sample. Severity is decided by the sync (checksum validated cards, SSN, ACH, medical record
  numbers and so on are "high"; three kinds of high data or 10+ high hits in one item is "critical").
-->
<group name="claude_enterprise,claude_dlp,">

  <rule id="101830" level="0">
    <decoded_as>json</decoded_as>
    <field name="integration">^claude-enterprise$</field>
    <field name="feed">^content$</field>
    <description>Claude Enterprise content scan feed</description>
  </rule>

  <rule id="101831" level="12">
    <if_sid>101830</if_sid>
    <field name="type">^claude_sensitive_data$</field>
    <field name="dlp.severity">^critical$</field>
    <description>Claude sensitive data CRITICAL: $(dlp.category) ($(dlp.labels)) in a $(dlp.source) by $(srcuser), $(dlp.total) hits</description>
    <group>claude_dlp_finding,claude_dlp_critical,</group>
  </rule>

  <rule id="101832" level="10">
    <if_sid>101830</if_sid>
    <field name="type">^claude_sensitive_data$</field>
    <field name="dlp.severity">^high$</field>
    <description>Claude sensitive data: $(dlp.category) ($(dlp.labels)) in a $(dlp.source) by $(srcuser), $(dlp.total) hits</description>
    <group>claude_dlp_finding,claude_dlp_high,</group>
  </rule>

  <rule id="101833" level="7">
    <if_sid>101830</if_sid>
    <field name="type">^claude_sensitive_data$</field>
    <field name="dlp.severity">^medium$</field>
    <description>Claude sensitive data (medium): $(dlp.category) ($(dlp.labels)) in a $(dlp.source) by $(srcuser), $(dlp.total) hits</description>
    <group>claude_dlp_finding,claude_dlp_medium,</group>
  </rule>

  <rule id="101834" level="5">
    <if_sid>101830</if_sid>
    <field name="type">^claude_sensitive_data$</field>
    <description>Claude sensitive data (low): $(dlp.category) ($(dlp.labels)) in a $(dlp.source) by $(srcuser), $(dlp.total) hits</description>
    <group>claude_dlp_finding,claude_dlp_low,</group>
  </rule>

  <rule id="101836" level="8">
    <if_sid>101830</if_sid>
    <field name="type">^athena_dlp_sync_heartbeat$</field>
    <field name="dlp_sync.status">^error$</field>
    <description>Claude sensitive data scan ERROR: $(dlp_sync.error)</description>
    <group>claude_dlp_heartbeat,claude_dlp_error,</group>
  </rule>

  <rule id="101835" level="3">
    <if_sid>101830</if_sid>
    <field name="type">^athena_dlp_sync_heartbeat$</field>
    <description>Claude sensitive data scan heartbeat: status=$(dlp_sync.status), items scanned=$(dlp_sync.items_scanned), findings=$(dlp_sync.findings)</description>
    <group>claude_dlp_heartbeat,</group>
  </rule>

</group>
__EOF_rules_dlp__
ok "rules 101700-101836 in $RULES_DIR"

python3 - "$OSSEC_CONF" "$SYNC_DIR" $LOCALFILES <<'PY'
import sys
p, d, files = sys.argv[1], sys.argv[2], sys.argv[3:]
s = open(p).read()
add = ""
for f in files:
    loc = "%s/%s" % (d, f)
    if loc not in s:
        add += "\n  <localfile>\n    <log_format>json</log_format>\n    <location>%s</location>\n  </localfile>\n" % loc
if add:
    i = s.rindex("</ossec_config>")
    open(p, "w").write(s[:i].rstrip("\n") + "\n" + add + "\n" + s[i:])
    print("  added %d localfile block(s) to %s" % (add.count("<localfile>"), p))
else:
    print("  localfile blocks already present")
PY

if /var/ossec/bin/wazuh-analysisd -t >/tmp/claude-analysisd-test.log 2>&1; then ok "Wazuh accepts the rules and ossec.conf"
else
  cat /tmp/claude-analysisd-test.log >&2
  for f in $RULE_FILES; do if [ -e "$RULES_BAK/$f" ]; then cp -p "$RULES_BAK/$f" "$RULES_DIR/$f"; else rm -f "$RULES_DIR/$f"; fi; done
  cp -p "$RULES_BAK/ossec.conf" "$OSSEC_CONF"
  die "Wazuh rejected the configuration; the rules and ossec.conf were put back as they were"
fi

if [ "$YES" -eq 1 ] || [ -z "$TTY" ]; then a=y; else read -rp "Restart wazuh-manager now (needed to load the rules and log sources)? [Y/n] " a < "$TTY"; fi
if [ "${a:-y}" != n ] && [ "${a:-y}" != N ]; then systemctl restart wazuh-manager && ok "wazuh-manager restarted"
else warn "not restarted: run 'systemctl restart wazuh-manager' before the events can be rated"; fi

# ------------------------------------------------------------------------------------------------ indexer
step "Creating the alert-state index"
code=$(ix -o /dev/null -w '%{http_code}' -m 20 "$INDEXER_URL/$STATE_INDEX" 2>/dev/null) || code=000
if [ "$code" = 200 ]; then ok "$STATE_INDEX already exists"; else
  out=$(ix -m 30 -X PUT -H 'Content-Type: application/json' "$INDEXER_URL/$STATE_INDEX" \
    -d '{"settings":{"number_of_shards":1,"number_of_replicas":0},"mappings":{"properties":{"status":{"type":"keyword"},"at":{"type":"long"},"by":{"type":"keyword"}}}}') || out=""
  echo "$out" | grep -q '"acknowledged":true' && ok "created $STATE_INDEX (alert acknowledge / close state)" || warn "could not create $STATE_INDEX: $out"
fi

# ------------------------------------------------------------------------------------------------ start
step "Starting the sync service"
systemctl daemon-reload
systemctl enable claude-sync >/dev/null 2>&1 || true
systemctl restart claude-sync
sleep 3
systemctl is-active --quiet claude-sync && ok "claude-sync is running" || { journalctl -u claude-sync -n 20 --no-pager >&2; die "claude-sync did not start"; }

step "Waiting for the first events to reach wazuh-alerts-* (up to 6 minutes)"
count_events() { ix -m 20 -X POST -H 'Content-Type: application/json' "$INDEXER_URL/wazuh-alerts-*/_search?ignore_unavailable=true&size=0" \
  -d '{"query":{"term":{"data.integration":"claude-enterprise"}},"aggs":{"feed":{"terms":{"field":"data.feed"}}}}' 2>/dev/null \
  | python3 -c 'import json,sys
try:
    d=json.load(sys.stdin); t=d["hits"]["total"]["value"]; f={b["key"]:b["doc_count"] for b in d["aggregations"]["feed"]["buckets"]}
    print(t, " ".join("%s=%s" % kv for kv in sorted(f.items())))
except Exception: print("0")' || echo 0; }
seen=""; for i in $(seq 1 36); do
  seen=$(count_events); n=${seen%% *}
  if [ "${n:-0}" -gt 0 ] 2>/dev/null; then break; fi
  printf '.'; sleep 10
done; echo
if [ "${seen%% *}" -gt 0 ] 2>/dev/null; then ok "events are in the indexer: ${seen}"
else warn "no Claude events in wazuh-alerts-* yet. Check: journalctl -u claude-sync -n 50 ; tail /var/ossec/logs/ossec.log ; filebeat/indexer health"; fi

cat <<EOF

${B}Done.${N}
  Service        systemctl status claude-sync        journalctl -u claude-sync -f
  Tunables       $ENV_DIR/env  (then: systemctl restart claude-sync)
  Compliance key systemctl edit $KEY_UNIT   ($KEY_TARGET), then: systemctl restart claude-sync
  Rules          $RULES_DIR/claude_*.xml
  Data buffers   $SYNC_DIR/claude_*.jsonl  (rotated daily; real data lives in wazuh-alerts-*)
  Alert state    index '$STATE_INDEX' in the indexer (no state files)
The first run back-fills what the Compliance API still holds; the content scan and usage feeds follow within a few minutes.
EOF
