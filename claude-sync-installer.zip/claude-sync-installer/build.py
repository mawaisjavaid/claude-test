#!/usr/bin/env python3
"""Embed src/* into installer.template.sh and write install-claude-sync.sh (one self-contained script)."""
import os, re, stat

HERE = os.path.dirname(os.path.abspath(__file__))
t = open(os.path.join(HERE, 'installer.template.sh')).read()


def embed(m):
    rel = m.group(1)
    body = open(os.path.join(HERE, rel)).read()
    if not body.endswith('\n'):
        body += '\n'
    for line in body.splitlines():
        assert not re.fullmatch(r'__EOF_\w+__', line), 'heredoc terminator inside ' + rel
    return body.rstrip('\n')


out = re.sub(r'@@FILE:([\w./-]+)@@', embed, t)
assert '@@FILE' not in out
dst = os.path.join(HERE, 'install-claude-sync.sh')
open(dst, 'w').write(out)
os.chmod(dst, 0o755)
print('wrote', dst, len(out), 'bytes')
