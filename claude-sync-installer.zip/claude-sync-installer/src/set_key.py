#!/usr/bin/env python3
"""Put ANTHROPIC_COMPLIANCE_KEY into a systemd drop-in (the equivalent of `systemctl edit <unit>`), idempotently.
usage: set_key.py DROPIN_FILE      (the key is read from the environment variable NEW_KEY, never from argv)"""
import os, re, shutil, stat, sys, time

path, key = sys.argv[1], os.environ["NEW_KEY"]
esc = key.replace("\\", "\\\\").replace('"', '\\"').replace("%", "%%")
line = 'Environment="ANTHROPIC_COMPLIANCE_KEY=%s"\n' % esc
old = open(path).read() if os.path.exists(path) else ""
kept = [l for l in old.splitlines(True) if not re.match(r'\s*Environment=\s*"?ANTHROPIC_COMPLIANCE_KEY=', l)]
if not any(l.strip() == "[Service]" for l in kept):
    kept = ["[Service]\n"] + kept
i = next(n for n, l in enumerate(kept) if l.strip() == "[Service]")
kept.insert(i + 1, line)
if os.path.exists(path):
    b = "%s.bak-%s" % (path, time.strftime("%Y%m%d-%H%M%S"))
    shutil.copy2(path, b); os.chmod(b, 0o600)
tmp = path + ".tmp"
with open(tmp, "w") as f:
    f.write("".join(kept))
os.chmod(tmp, 0o600)
os.replace(tmp, path)
